﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TransitSoftBO;

namespace PruebasUnitarias
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int opcion = -1;

            var bo = new CamaraBO();

            while (opcion != 0)
            {
                Console.Clear();
                Console.WriteLine("=====================================");
                Console.WriteLine("   TESTER - Servicio CamaraWS");
                Console.WriteLine("=====================================");
                Console.WriteLine("1. Insertar Cámara");
                Console.WriteLine("2. Listar Todas las Cámaras");
                Console.WriteLine("3. Obtener Cámara por ID");
                Console.WriteLine("4. Modificar Cámara");
                Console.WriteLine("5. Eliminar Cámara");
                Console.WriteLine("-------------------------------------");
                Console.WriteLine("0. Salir");
                Console.Write("Selecciona una opción: ");

                int.TryParse(Console.ReadLine(), out opcion);
                Console.Clear();

                switch (opcion)
                {
                    case 1: InsertarCamara(bo); break;
                    case 2: ListarCamaras(bo); break;
                    case 3: ObtenerCamara(bo); break;
                    case 4: ModificarCamara(bo); break;
                    case 5: EliminarCamara(bo); break;
                }

                if (opcion != 0)
                {
                    Console.WriteLine("\nPresiona cualquier tecla para continuar...");
                    Console.ReadKey();
                }
            }
        }

        // ============================================================
        // INSERTAR
        // ============================================================
        static void InsertarCamara(CamaraBO bo)
        {
            Console.WriteLine("=== Insertar Cámara ===");

            Console.Write("Modelo: ");
            string modelo = Console.ReadLine();

            Console.Write("Código de Serie: ");
            string serie = Console.ReadLine();

            Console.Write("Latitud (entero): ");
            int lat = int.Parse(Console.ReadLine());

            Console.Write("Longitud (entero): ");
            int lon = int.Parse(Console.ReadLine());

            int id = bo.Insertar(modelo, serie, lat, lon);
            Console.WriteLine("\nCámara insertada correctamente. ID = " + id);
        }

        // ============================================================
        // LISTAR
        // ============================================================
        static void ListarCamaras(CamaraBO bo)
        {
            Console.WriteLine("=== Listar Cámaras ===");

            var lista = bo.ListarTodos();

            if (lista == null || lista.Count == 0)
            {
                Console.WriteLine("No hay cámaras registradas.");
                return;
            }

            foreach (var c in lista)
            {
                Console.WriteLine($"{c.id} | {c.modelo} | {c.codigoSerie} | Lat={c.latitud} | Lon={c.longitud}");
            }
        }

        // ============================================================
        // OBTENER POR ID
        // ============================================================
        static void ObtenerCamara(CamaraBO bo)
        {
            Console.WriteLine("=== Obtener Cámara por ID ===");

            Console.Write("ID: ");
            int id = int.Parse(Console.ReadLine());

            var c = bo.ObtenerPorId(id);

            if (c == null)
            {
                Console.WriteLine("No se encontró la cámara.");
                return;
            }

            Console.WriteLine($"\nID: {c.id}");
            Console.WriteLine($"Modelo: {c.modelo}");
            Console.WriteLine($"Código Serie: {c.codigoSerie}");
            Console.WriteLine($"Latitud: {c.latitud}");
            Console.WriteLine($"Longitud: {c.longitud}");
        }

        // ============================================================
        // MODIFICAR
        // ============================================================
        static void ModificarCamara(CamaraBO bo)
        {
            Console.WriteLine("=== Modificar Cámara ===");

            Console.Write("ID: ");
            int id = int.Parse(Console.ReadLine());

            Console.Write("Nuevo Modelo: ");
            string modelo = Console.ReadLine();

            Console.Write("Nuevo Código Serie: ");
            string serie = Console.ReadLine();

            Console.Write("Nueva Latitud: ");
            int lat = int.Parse(Console.ReadLine());

            Console.Write("Nueva Longitud: ");
            int lon = int.Parse(Console.ReadLine());

            int r = bo.Modificar(id, modelo, serie, lat, lon);

            Console.WriteLine("\nResultado = " + r);
            Console.WriteLine("1 = Modificado | 0 = NO modificado");
        }

        // ============================================================
        // ELIMINAR
        // ============================================================
        static void EliminarCamara(CamaraBO bo)
        {
            Console.WriteLine("=== Eliminar Cámara ===");

            Console.Write("ID: ");
            int id = int.Parse(Console.ReadLine());

            int r = bo.Eliminar(id);

            Console.WriteLine("\nResultado = " + r);
            Console.WriteLine("1 = Eliminado | 0 = NO eliminado");
        }
    }
}
