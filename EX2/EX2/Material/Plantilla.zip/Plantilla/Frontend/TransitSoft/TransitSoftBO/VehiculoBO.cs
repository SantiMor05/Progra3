﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TransitSoftBO.ServiciosWS;

namespace TransitSoftBO
{
    public class VehiculoBO
    {
        private VehiculoWebServiceClient clienteSOAP;

        public VehiculoBO()
        {
            clienteSOAP = new VehiculoWebServiceClient();
        }

        public int Insertar(string placa, string marca, string modelo, int anio)
        {
            return clienteSOAP.insertarVehiculo(placa, marca, modelo, anio);
        }

        public int Modificar(int id, string placa, string marca, string modelo, int anio)
        {
            return clienteSOAP.modificarVehiculo(id, placa, marca, modelo, anio);
        }

        public int Eliminar(int vehiculoId)
        {
            return clienteSOAP.eliminarVehiculo(vehiculoId);
        }

        public vehiculoDTO ObtenerPorId(int vehiculoId)
        {
            return clienteSOAP.obtenerVehiculoPorId(vehiculoId);
        }

        public IList<vehiculoDTO> ListarTodos()
        {
            return clienteSOAP.listarTodosVehiculos();
        }

        public IList<vehiculoDTO> BuscarPorPlaca(string placa)
        {
            return clienteSOAP.buscarVehiculoPorPlaca(placa);
        }

        public IList<vehiculoDTO> BuscarPorMarca(string marca)
        {
            return clienteSOAP.buscarVehiculoPorMarca(marca);
        }

        public IList<vehiculoDTO> BuscarPorAnio(int anio)
        {
            return clienteSOAP.buscarVehiculoPorAnio(anio);
        }
    }
}
