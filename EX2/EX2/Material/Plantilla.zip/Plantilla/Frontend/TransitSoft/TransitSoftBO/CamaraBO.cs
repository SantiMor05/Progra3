﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TransitSoftBO.ServiciosWS;

namespace TransitSoftBO
{
    public class CamaraBO
    {
        private CamaraWebServiceClient clienteSOAP;

        public CamaraBO()
        {
            this.clienteSOAP = new CamaraWebServiceClient();
        }

        public int Insertar(string modelo, string codigoSerie, int latitud, int longitud)
        {
            return clienteSOAP.insertarCamara(modelo, codigoSerie, latitud, longitud);
        }

        public int Modificar(int id, string modelo, string codigoSerie, int latitud, int longitud)
        {
            return clienteSOAP.modificarCamara(id, modelo, codigoSerie, latitud, longitud);
        }

        public int Eliminar(int camaraId)
        {
            return clienteSOAP.eliminarCamara(camaraId);
        }

        public camaraDTO ObtenerPorId(int camaraId)
        {
            return clienteSOAP.obtenerCamaraPorId(camaraId);
        }

        public IList<camaraDTO> ListarTodos()
        {
            return clienteSOAP.listarTodasCamaras();
        }

        public IList<camaraDTO> BuscarPorModelo(string modelo)
        {
            return clienteSOAP.buscarCamaraPorModelo(modelo);
        }

        public IList<camaraDTO> BuscarPorCodigoSerie(string codigoSerie)
        {
            return clienteSOAP.buscarCamaraPorCodigoSerie(codigoSerie);
        }

        public IList<camaraDTO> BuscarPorZonaGeografica(int latMin, int latMax, int longMin, int longMax)
        {
            return clienteSOAP.buscarCamaraPorZonaGeografica(latMin, latMax, longMin, longMax);
        }
    }
}
