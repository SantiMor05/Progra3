﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TransitSoftBO.ServiciosWS;

namespace TransitSoftBO
{
    public class VehiculoPropietarioBO
    {
        private VehiculoPropietarioWebServiceClient clienteSOAP;

        public VehiculoPropietarioBO()
        {
            clienteSOAP = new VehiculoPropietarioWebServiceClient();
        }

        public int Insertar(vehiculoPropietarioDTO dto)
        {
            return clienteSOAP.insertarVehiculoPropietario(dto);
        }

        public int Modificar(vehiculoPropietarioDTO dto)
        {
            return clienteSOAP.modificarVehiculoPropietario(dto);
        }

        public int Eliminar(int id)
        {
            return clienteSOAP.eliminarVehiculoPropietario(id);
        }

        public vehiculoPropietarioDTO ObtenerPorId(int id)
        {
            return clienteSOAP.obtenerVehiculoPropietarioPorId(id);
        }

        public IList<vehiculoPropietarioDTO> ListarTodos()
        {
            return clienteSOAP.listarTodosVehiculosPropietarios();
        }

        public IList<vehiculoPropietarioDTO> BuscarPorVehiculoId(int vehiculoId)
        {
            return clienteSOAP.buscarVehiculoPropietarioPorVehiculoId(vehiculoId);
        }

        public IList<vehiculoPropietarioDTO> BuscarPorPropietarioId(int propietarioId)
        {
            return clienteSOAP.buscarVehiculoPropietarioPorPropietarioId(propietarioId);
        }

        public IList<vehiculoPropietarioDTO> BuscarPorPlaca(string placa)
        {
            return clienteSOAP.buscarVehiculoPropietarioPorPlaca(placa);
        }
    }
}
