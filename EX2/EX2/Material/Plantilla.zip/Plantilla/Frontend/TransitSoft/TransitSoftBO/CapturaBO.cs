﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TransitSoftBO.ServiciosWS;

namespace TransitSoftBO
{
    public class CapturaBO
    {
        private CapturaWebServiceClient clienteSOAP;

        public CapturaBO()
        {
            clienteSOAP = new CapturaWebServiceClient();
        }

        public int Insertar(capturaDTO dto)
        {
            return clienteSOAP.insertarCaptura(dto);
        }

        public int Modificar(capturaDTO dto)
        {
            return clienteSOAP.modificarCaptura(dto);
        }

        public int Actualizar(capturaDTO dto)
        {
            return clienteSOAP.actualizarCaptura(dto);
        }

        public int Eliminar(int capturaId)
        {
            return clienteSOAP.eliminarCaptura(capturaId);
        }

        public capturaDTO ObtenerPorId(int capturaId)
        {
            return clienteSOAP.obtenerCapturaPorId(capturaId);
        }

        public IList<capturaDTO> ListarTodos()
        {
            return clienteSOAP.listarTodasCapturas();
        }

        public IList<capturaDTO> LeerTodos()
        {
            return clienteSOAP.leerTodasCapturas();
        }

        public IList<capturaDTO> ObtenerConExcesoVelocidad()
        {
            return clienteSOAP.obtenerCapturasConExcesoVelocidad();
        }

        public IList<capturaDTO> ObtenerConExcesoVelocidadConLimite(double limite)
        {
            return clienteSOAP.obtenerCapturasConExcesoVelocidadConLimite(limite);
        }

        public IList<capturaDTO> BuscarPorPlaca(string placa)
        {
            return clienteSOAP.buscarCapturaPorPlaca(placa);
        }

        public IList<capturaDTO> BuscarPorEstado(string estado)
        {
            return clienteSOAP.buscarCapturaPorEstado(estado);
        }

        public IList<capturaDTO> BuscarPorRangoFechas(System.DateTime inicio, System.DateTime fin)
        {
            return clienteSOAP.buscarCapturaPorRangoFechas(inicio, fin);
        }

        public IList<capturaDTO> BuscarPorCamara(int camaraId)
        {
            return clienteSOAP.buscarCapturaPorCamara(camaraId);
        }

        public void MarcarComoProcesado(int capturaId)
        {
            clienteSOAP.marcarCapturaComoProcesado(capturaId);
        }
    }
}
