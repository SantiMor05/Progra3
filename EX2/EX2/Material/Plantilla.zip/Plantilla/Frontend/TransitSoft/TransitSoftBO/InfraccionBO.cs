﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TransitSoftBO.ServiciosWS;

namespace TransitSoftBO
{
    public class InfraccionBO
    {
        private InfraccionWebServiceClient clienteSOAP;

        public InfraccionBO()
        {
            clienteSOAP = new InfraccionWebServiceClient();
        }

        public int Insertar(infraccionDTO dto)
        {
            return clienteSOAP.insertarInfraccion(dto);
        }

        public int Modificar(infraccionDTO dto)
        {
            return clienteSOAP.modificarInfraccion(dto);
        }

        public int Eliminar(int infraccionId)
        {
            return clienteSOAP.eliminarInfraccion(infraccionId);
        }

        public infraccionDTO ObtenerPorId(int infraccionId)
        {
            return clienteSOAP.obtenerInfraccionPorId(infraccionId);
        }

        public IList<infraccionDTO> ListarTodos()
        {
            return clienteSOAP.listarTodasInfracciones();
        }

        public IList<infraccionDTO> BuscarPorPlaca(string placa)
        {
            return clienteSOAP.buscarInfraccionPorPlaca(placa);
        }

        public IList<infraccionDTO> BuscarPorRangoFechas(System.DateTime inicio, System.DateTime fin)
        {
            return clienteSOAP.buscarInfraccionPorRangoFechas(inicio, fin);
        }

        public IList<infraccionDTO> BuscarPorExcesoMayorA(double exceso)
        {
            return clienteSOAP.buscarInfraccionPorExcesoMayorA(exceso);
        }

        public IList<infraccionDTO> BuscarPorCamara(int camaraId)
        {
            return clienteSOAP.buscarInfraccionPorCamara(camaraId);
        }

        public double CalcularMontoTotal()
        {
            return clienteSOAP.calcularMontoTotalInfracciones();
        }

        public double CalcularMontoTotalPorPlaca(string placa)
        {
            return clienteSOAP.calcularMontoTotalInfraccionesPorPlaca(placa);
        }
    }
}
