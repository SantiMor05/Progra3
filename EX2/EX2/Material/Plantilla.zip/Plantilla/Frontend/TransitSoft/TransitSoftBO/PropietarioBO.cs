﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TransitSoftBO.ServiciosWS;

namespace TransitSoftBO
{
    public class PropietarioBO
    {
        private PropietarioWebServiceClient clienteSOAP;

        public PropietarioBO()
        {
            clienteSOAP = new PropietarioWebServiceClient();
        }

        public int Insertar(string dni, string nombres, string apellidos, string direccion)
        {
            return clienteSOAP.insertarPropietario(dni, nombres, apellidos, direccion);
        }

        public int Modificar(int id, string dni, string nombres, string apellidos, string direccion)
        {
            return clienteSOAP.modificarPropietario(id, dni, nombres, apellidos, direccion);
        }

        public int Eliminar(int propietarioId)
        {
            return clienteSOAP.eliminarPropietario(propietarioId);
        }

        public propietarioDTO ObtenerPorId(int propietarioId)
        {
            return clienteSOAP.obtenerPropietarioPorId(propietarioId);
        }

        public IList<propietarioDTO> ListarTodos()
        {
            return clienteSOAP.listarTodosPropietarios();
        }

        public IList<propietarioDTO> BuscarPorDni(string dni)
        {
            return clienteSOAP.buscarPropietarioPorDni(dni);
        }

        public IList<propietarioDTO> BuscarPorNombre(string nombre)
        {
            return clienteSOAP.buscarPropietarioPorNombre(nombre);
        }
    }
}
