package pe.edu.pucp.transitsoft.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import jakarta.jws.WebService;
import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import java.io.IOException;
import java.util.ArrayList;
import pe.edu.pucp.transitsoft.clienteBO.VehiculoPropietarioBOClient;
import transitsoft.model.VehiculoPropietarioDTO;

@WebService(serviceName = "VehiculoPropietarioWS")
public class VehiculoPropietarioWebService {
    private VehiculoPropietarioBOClient vehiculoPropietarioBO;
    
    public VehiculoPropietarioWebService() {
        this.vehiculoPropietarioBO = new VehiculoPropietarioBOClient();
    }
    
    @WebMethod(operationName = "insertarVehiculoPropietario")
    public Integer insertarVehiculoPropietario(@WebParam(name = "vehiculoPropietarioDTO") VehiculoPropietarioDTO vehiculoPropietarioDTO) 
            throws IOException, JsonProcessingException, InterruptedException {
        return this.vehiculoPropietarioBO.insertar(vehiculoPropietarioDTO);
    }
    
    @WebMethod(operationName = "modificarVehiculoPropietario")
    public Integer modificarVehiculoPropietario(@WebParam(name = "vehiculoPropietarioDTO") VehiculoPropietarioDTO vehiculoPropietarioDTO) 
            throws IOException, JsonProcessingException, InterruptedException {
        return this.vehiculoPropietarioBO.modificar(vehiculoPropietarioDTO);
    }
    
    @WebMethod(operationName = "eliminarVehiculoPropietario")
    public Integer eliminarVehiculoPropietario(@WebParam(name = "vehiculoPropietarioId") Integer vehiculoPropietarioId) 
            throws IOException, InterruptedException {
        return this.vehiculoPropietarioBO.eliminar(vehiculoPropietarioId);
    }
    
    @WebMethod(operationName = "obtenerVehiculoPropietarioPorId")
    public VehiculoPropietarioDTO obtenerVehiculoPropietarioPorId(@WebParam(name = "vehiculoPropietarioId") Integer vehiculoPropietarioId) 
            throws IOException, InterruptedException {
        return this.vehiculoPropietarioBO.obtenerPorId(vehiculoPropietarioId);
    }
    
    @WebMethod(operationName = "listarTodosVehiculosPropietarios")
    public ArrayList<VehiculoPropietarioDTO> listarTodosVehiculosPropietarios() throws IOException, InterruptedException {
        return this.vehiculoPropietarioBO.listarTodos();
    }
    
    @WebMethod(operationName = "buscarVehiculoPropietarioPorVehiculoId")
    public ArrayList<VehiculoPropietarioDTO> buscarVehiculoPropietarioPorVehiculoId(@WebParam(name = "vehiculoId") Integer vehiculoId) 
            throws IOException, InterruptedException {
        return this.vehiculoPropietarioBO.buscarPorVehiculoId(vehiculoId);
    }
    
    @WebMethod(operationName = "buscarVehiculoPropietarioPorPropietarioId")
    public ArrayList<VehiculoPropietarioDTO> buscarVehiculoPropietarioPorPropietarioId(@WebParam(name = "propietarioId") Integer propietarioId) 
            throws IOException, InterruptedException {
        return this.vehiculoPropietarioBO.buscarPorPropietarioId(propietarioId);
    }
    
    @WebMethod(operationName = "buscarVehiculoPropietarioPorPlaca")
    public ArrayList<VehiculoPropietarioDTO> buscarVehiculoPropietarioPorPlaca(@WebParam(name = "placa") String placa) 
            throws IOException, InterruptedException {
        return this.vehiculoPropietarioBO.buscarPorPlaca(placa);
    }
}