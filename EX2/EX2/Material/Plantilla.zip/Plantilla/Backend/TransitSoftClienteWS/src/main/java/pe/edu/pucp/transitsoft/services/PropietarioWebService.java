package pe.edu.pucp.transitsoft.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import jakarta.jws.WebService;
import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import java.io.IOException;
import java.util.ArrayList;
import pe.edu.pucp.transitsoft.clienteBO.PropietarioBOClient;
import transitsoft.model.PropietarioDTO;

@WebService(serviceName = "PropietarioWS")
public class PropietarioWebService {
    private PropietarioBOClient propietarioBO;
    
    public PropietarioWebService() {
        this.propietarioBO = new PropietarioBOClient();
    }
    
    @WebMethod(operationName = "insertarPropietario")
    public Integer insertarPropietario(
            @WebParam(name = "dni") String dni,
            @WebParam(name = "nombres") String nombres,
            @WebParam(name = "apellidos") String apellidos,
            @WebParam(name = "direccion") String direccion) 
            throws IOException, JsonProcessingException, InterruptedException {
        return this.propietarioBO.insertar(dni, nombres, apellidos, direccion);
    }
    
    @WebMethod(operationName = "modificarPropietario")
    public Integer modificarPropietario(
            @WebParam(name = "id") Integer id,
            @WebParam(name = "dni") String dni,
            @WebParam(name = "nombres") String nombres,
            @WebParam(name = "apellidos") String apellidos,
            @WebParam(name = "direccion") String direccion) 
            throws IOException, JsonProcessingException, InterruptedException {
        return this.propietarioBO.modificar(id, dni, nombres, apellidos, direccion);
    }
    
    @WebMethod(operationName = "eliminarPropietario")
    public Integer eliminarPropietario(@WebParam(name = "propietarioId") Integer propietarioId) 
            throws IOException, InterruptedException {
        return this.propietarioBO.eliminar(propietarioId);
    }
    
    @WebMethod(operationName = "obtenerPropietarioPorId")
    public PropietarioDTO obtenerPropietarioPorId(@WebParam(name = "propietarioId") Integer propietarioId) 
            throws IOException, InterruptedException {
        return this.propietarioBO.obtenerPorId(propietarioId);
    }
    
    @WebMethod(operationName = "listarTodosPropietarios")
    public ArrayList<PropietarioDTO> listarTodosPropietarios() throws IOException, InterruptedException {
        return this.propietarioBO.listarTodos();
    }
    
    @WebMethod(operationName = "buscarPropietarioPorDni")
    public ArrayList<PropietarioDTO> buscarPropietarioPorDni(@WebParam(name = "dni") String dni) 
            throws IOException, InterruptedException {
        return this.propietarioBO.buscarPorDni(dni);
    }
    
    @WebMethod(operationName = "buscarPropietarioPorNombre")
    public ArrayList<PropietarioDTO> buscarPropietarioPorNombre(@WebParam(name = "nombre") String nombre) 
            throws IOException, InterruptedException {
        return this.propietarioBO.buscarPorNombre(nombre);
    }
}