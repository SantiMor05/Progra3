package pe.edu.pucp.transitsoft.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import jakarta.jws.WebService;
import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import java.io.IOException;
import java.util.ArrayList;
import pe.edu.pucp.transitsoft.clienteBO.VehiculoBOClient;
import transitsoft.model.VehiculoDTO;

@WebService(serviceName = "VehiculoWS")
public class VehiculoWebService {
    private VehiculoBOClient vehiculoBO;
    
    public VehiculoWebService() {
        this.vehiculoBO = new VehiculoBOClient();
    }
    
    @WebMethod(operationName = "insertarVehiculo")
    public Integer insertarVehiculo(
            @WebParam(name = "placa") String placa,
            @WebParam(name = "marca") String marca,
            @WebParam(name = "modelo") String modelo,
            @WebParam(name = "anho") Integer anho) 
            throws IOException, JsonProcessingException, InterruptedException {
        return this.vehiculoBO.insertar(placa, marca, modelo, anho);
    }
    
    @WebMethod(operationName = "modificarVehiculo")
    public Integer modificarVehiculo(
            @WebParam(name = "id") Integer id,
            @WebParam(name = "placa") String placa,
            @WebParam(name = "marca") String marca,
            @WebParam(name = "modelo") String modelo,
            @WebParam(name = "anho") Integer anho) 
            throws IOException, JsonProcessingException, InterruptedException {
        return this.vehiculoBO.modificar(id, placa, marca, modelo, anho);
    }
    
    @WebMethod(operationName = "eliminarVehiculo")
    public Integer eliminarVehiculo(@WebParam(name = "vehiculoId") Integer vehiculoId) 
            throws IOException, InterruptedException {
        return this.vehiculoBO.eliminar(vehiculoId);
    }
    
    @WebMethod(operationName = "obtenerVehiculoPorId")
    public VehiculoDTO obtenerVehiculoPorId(@WebParam(name = "vehiculoId") Integer vehiculoId) 
            throws IOException, InterruptedException {
        return this.vehiculoBO.obtenerPorId(vehiculoId);
    }
    
    @WebMethod(operationName = "listarTodosVehiculos")
    public ArrayList<VehiculoDTO> listarTodosVehiculos() throws IOException, InterruptedException {
        return this.vehiculoBO.listarTodos();
    }
    
    @WebMethod(operationName = "buscarVehiculoPorPlaca")
    public ArrayList<VehiculoDTO> buscarVehiculoPorPlaca(@WebParam(name = "placa") String placa) 
            throws IOException, InterruptedException {
        return this.vehiculoBO.buscarPorPlaca(placa);
    }
    
    @WebMethod(operationName = "buscarVehiculoPorMarca")
    public ArrayList<VehiculoDTO> buscarVehiculoPorMarca(@WebParam(name = "marca") String marca) 
            throws IOException, InterruptedException {
        return this.vehiculoBO.buscarPorMarca(marca);
    }
    
    @WebMethod(operationName = "buscarVehiculoPorAnio")
    public ArrayList<VehiculoDTO> buscarVehiculoPorAnio(@WebParam(name = "anio") Integer anio) 
            throws IOException, InterruptedException {
        return this.vehiculoBO.buscarPorAnio(anio);
    }
}