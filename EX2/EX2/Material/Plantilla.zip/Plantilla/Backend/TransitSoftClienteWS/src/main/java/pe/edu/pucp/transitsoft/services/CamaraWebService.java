package pe.edu.pucp.transitsoft.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import jakarta.jws.WebService;
import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import java.io.IOException;
import java.util.ArrayList;
import pe.edu.pucp.transitsoft.clienteBO.CamaraBOClient;
import transitsoft.model.CamaraDTO;

@WebService(serviceName = "CamaraWS")
public class CamaraWebService {
    private CamaraBOClient camaraBO;
    
    public CamaraWebService() {
        this.camaraBO = new CamaraBOClient();
    }
    
    @WebMethod(operationName = "insertarCamara")
    public Integer insertarCamara(
            @WebParam(name = "modelo") String modelo,
            @WebParam(name = "codigoSerie") String codigoSerie,
            @WebParam(name = "latitud") Integer latitud,
            @WebParam(name = "longitud") Integer longitud) 
            throws IOException, JsonProcessingException, InterruptedException {
        return this.camaraBO.insertar(modelo, codigoSerie, latitud, longitud);
    }
    
    @WebMethod(operationName = "modificarCamara")
    public Integer modificarCamara(
            @WebParam(name = "id") Integer id,
            @WebParam(name = "modelo") String modelo,
            @WebParam(name = "codigoSerie") String codigoSerie,
            @WebParam(name = "latitud") Integer latitud,
            @WebParam(name = "longitud") Integer longitud) 
            throws IOException, JsonProcessingException, InterruptedException {
        return this.camaraBO.modificar(id, modelo, codigoSerie, latitud, longitud);
    }
    
    @WebMethod(operationName = "eliminarCamara")
    public Integer eliminarCamara(@WebParam(name = "camaraId") Integer camaraId) 
            throws IOException, InterruptedException {
        return this.camaraBO.eliminar(camaraId);
    }
    
    @WebMethod(operationName = "obtenerCamaraPorId")
    public CamaraDTO obtenerCamaraPorId(@WebParam(name = "camaraId") Integer camaraId) 
            throws IOException, InterruptedException {
        return this.camaraBO.obtenerPorId(camaraId);
    }
    
    @WebMethod(operationName = "listarTodasCamaras")
    public ArrayList<CamaraDTO> listarTodasCamaras() throws IOException, InterruptedException {
        return this.camaraBO.listarTodos();
    }
    
    @WebMethod(operationName = "buscarCamaraPorModelo")
    public ArrayList<CamaraDTO> buscarCamaraPorModelo(@WebParam(name = "modelo") String modelo) 
            throws IOException, InterruptedException {
        return this.camaraBO.buscarPorModelo(modelo);
    }
    
    @WebMethod(operationName = "buscarCamaraPorCodigoSerie")
    public ArrayList<CamaraDTO> buscarCamaraPorCodigoSerie(@WebParam(name = "codigoSerie") String codigoSerie) 
            throws IOException, InterruptedException {
        return this.camaraBO.buscarPorCodigoSerie(codigoSerie);
    }
    
    @WebMethod(operationName = "buscarCamaraPorZonaGeografica")
    public ArrayList<CamaraDTO> buscarCamaraPorZonaGeografica(
            @WebParam(name = "latMin") Integer latMin,
            @WebParam(name = "latMax") Integer latMax,
            @WebParam(name = "longMin") Integer longMin,
            @WebParam(name = "longMax") Integer longMax) 
            throws IOException, InterruptedException {
        return this.camaraBO.buscarPorZonaGeografica(latMin, latMax, longMin, longMax);
    }
}