package pe.edu.pucp.transitsoft.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import jakarta.jws.WebService;
import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import pe.edu.pucp.transitsoft.clienteBO.CapturaBOClient;
import transitsoft.model.CapturaDTO;

@WebService(serviceName = "CapturaWS")
public class CapturaWebService {
    private CapturaBOClient capturaBO;
    
    public CapturaWebService() {
        this.capturaBO = new CapturaBOClient();
    }
    
    @WebMethod(operationName = "insertarCaptura")
    public Integer insertarCaptura(@WebParam(name = "capturaDTO") CapturaDTO capturaDTO) 
            throws IOException, JsonProcessingException, InterruptedException {
        return this.capturaBO.insertar(capturaDTO);
    }
    
    @WebMethod(operationName = "modificarCaptura")
    public Integer modificarCaptura(@WebParam(name = "capturaDTO") CapturaDTO capturaDTO) 
            throws IOException, JsonProcessingException, InterruptedException {
        return this.capturaBO.modificar(capturaDTO);
    }
    
    @WebMethod(operationName = "actualizarCaptura")
    public Integer actualizarCaptura(@WebParam(name = "capturaDTO") CapturaDTO capturaDTO) 
            throws IOException, JsonProcessingException, InterruptedException {
        return this.capturaBO.actualizar(capturaDTO);
    }
    
    @WebMethod(operationName = "eliminarCaptura")
    public Integer eliminarCaptura(@WebParam(name = "capturaId") Integer capturaId) 
            throws IOException, InterruptedException {
        return this.capturaBO.eliminar(capturaId);
    }
    
    @WebMethod(operationName = "obtenerCapturaPorId")
    public CapturaDTO obtenerCapturaPorId(@WebParam(name = "capturaId") Integer capturaId) 
            throws IOException, InterruptedException {
        return this.capturaBO.obtenerPorId(capturaId);
    }
    
    @WebMethod(operationName = "listarTodasCapturas")
    public ArrayList<CapturaDTO> listarTodasCapturas() throws IOException, InterruptedException {
        return this.capturaBO.listarTodos();
    }
    
    @WebMethod(operationName = "leerTodasCapturas")
    public List<CapturaDTO> leerTodasCapturas() throws IOException, InterruptedException {
        return this.capturaBO.leerTodos();
    }
    
    @WebMethod(operationName = "obtenerCapturasConExcesoVelocidad")
    public List<CapturaDTO> obtenerCapturasConExcesoVelocidad() 
            throws IOException, InterruptedException {
        return this.capturaBO.obtenerCapturasConExcesoDeVelocidad();
    }
    
    @WebMethod(operationName = "obtenerCapturasConExcesoVelocidadConLimite")
    public List<CapturaDTO> obtenerCapturasConExcesoVelocidadConLimite(@WebParam(name = "limite") Double limite) 
            throws IOException, InterruptedException {
        return this.capturaBO.obtenerCapturasConExcesoDeVelocidadConLimite(limite);
    }
    
    @WebMethod(operationName = "buscarCapturaPorPlaca")
    public List<CapturaDTO> buscarCapturaPorPlaca(@WebParam(name = "placa") String placa) 
            throws IOException, InterruptedException {
        return this.capturaBO.buscarPorPlaca(placa);
    }
    
    @WebMethod(operationName = "buscarCapturaPorEstado")
    public List<CapturaDTO> buscarCapturaPorEstado(@WebParam(name = "estado") String estado) 
            throws IOException, InterruptedException {
        return this.capturaBO.buscarPorEstado(estado);
    }
    
    @WebMethod(operationName = "buscarCapturaPorRangoFechas")
    public List<CapturaDTO> buscarCapturaPorRangoFechas(
            @WebParam(name = "fechaInicio") Date fechaInicio,
            @WebParam(name = "fechaFin") Date fechaFin) 
            throws IOException, InterruptedException {
        return this.capturaBO.buscarPorRangoFechas(fechaInicio, fechaFin);
    }
    
    @WebMethod(operationName = "buscarCapturaPorCamara")
    public List<CapturaDTO> buscarCapturaPorCamara(@WebParam(name = "camaraId") Integer camaraId) 
            throws IOException, InterruptedException {
        return this.capturaBO.buscarPorCamara(camaraId);
    }
    
    @WebMethod(operationName = "marcarCapturaComoProcesado")
    public void marcarCapturaComoProcesado(@WebParam(name = "capturaId") Integer capturaId) 
            throws IOException, InterruptedException {
        this.capturaBO.marcarComoProcesado(capturaId);
    }
}