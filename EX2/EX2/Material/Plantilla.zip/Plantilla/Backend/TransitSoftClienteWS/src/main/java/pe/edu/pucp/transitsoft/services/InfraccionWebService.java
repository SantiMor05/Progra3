package pe.edu.pucp.transitsoft.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import jakarta.jws.WebService;
import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import pe.edu.pucp.transitsoft.clienteBO.InfraccionBOClient;
import transitsoft.model.InfraccionDTO;

@WebService(serviceName = "InfraccionWS")
public class InfraccionWebService {
    private InfraccionBOClient infraccionBO;
    
    public InfraccionWebService() {
        this.infraccionBO = new InfraccionBOClient();
    }
    
    @WebMethod(operationName = "insertarInfraccion")
    public Integer insertarInfraccion(@WebParam(name = "infraccionDTO") InfraccionDTO infraccionDTO) 
            throws IOException, JsonProcessingException, InterruptedException {
        return this.infraccionBO.insertar(infraccionDTO);
    }
    
    @WebMethod(operationName = "modificarInfraccion")
    public Integer modificarInfraccion(@WebParam(name = "infraccionDTO") InfraccionDTO infraccionDTO) 
            throws IOException, JsonProcessingException, InterruptedException {
        return this.infraccionBO.modificar(infraccionDTO);
    }
    
    @WebMethod(operationName = "eliminarInfraccion")
    public Integer eliminarInfraccion(@WebParam(name = "infraccionId") Integer infraccionId) 
            throws IOException, InterruptedException {
        return this.infraccionBO.eliminar(infraccionId);
    }
    
    @WebMethod(operationName = "obtenerInfraccionPorId")
    public InfraccionDTO obtenerInfraccionPorId(@WebParam(name = "infraccionId") Integer infraccionId) 
            throws IOException, InterruptedException {
        return this.infraccionBO.obtenerPorId(infraccionId);
    }
    
    @WebMethod(operationName = "listarTodasInfracciones")
    public ArrayList<InfraccionDTO> listarTodasInfracciones() throws IOException, InterruptedException {
        return this.infraccionBO.listarTodos();
    }
    
    @WebMethod(operationName = "buscarInfraccionPorPlaca")
    public ArrayList<InfraccionDTO> buscarInfraccionPorPlaca(@WebParam(name = "placa") String placa) 
            throws IOException, InterruptedException {
        return this.infraccionBO.buscarPorPlaca(placa);
    }
    
    @WebMethod(operationName = "buscarInfraccionPorRangoFechas")
    public ArrayList<InfraccionDTO> buscarInfraccionPorRangoFechas(
            @WebParam(name = "fechaInicio") Date fechaInicio,
            @WebParam(name = "fechaFin") Date fechaFin) 
            throws IOException, InterruptedException {
        return this.infraccionBO.buscarPorRangoFechas(fechaInicio, fechaFin);
    }
    
    @WebMethod(operationName = "buscarInfraccionPorExcesoMayorA")
    public ArrayList<InfraccionDTO> buscarInfraccionPorExcesoMayorA(@WebParam(name = "excesoMinimo") Double excesoMinimo) 
            throws IOException, InterruptedException {
        return this.infraccionBO.buscarPorExcesoMayorA(excesoMinimo);
    }
    
    @WebMethod(operationName = "buscarInfraccionPorCamara")
    public ArrayList<InfraccionDTO> buscarInfraccionPorCamara(@WebParam(name = "camaraId") Integer camaraId) 
            throws IOException, InterruptedException {
        return this.infraccionBO.buscarPorCamara(camaraId);
    }
    
    @WebMethod(operationName = "calcularMontoTotalInfracciones")
    public Double calcularMontoTotalInfracciones() throws IOException, InterruptedException {
        return this.infraccionBO.calcularMontoTotal();
    }
    
    @WebMethod(operationName = "calcularMontoTotalInfraccionesPorPlaca")
    public Double calcularMontoTotalInfraccionesPorPlaca(@WebParam(name = "placa") String placa) 
            throws IOException, InterruptedException {
        return this.infraccionBO.calcularMontoTotalPorPlaca(placa);
    }
}
