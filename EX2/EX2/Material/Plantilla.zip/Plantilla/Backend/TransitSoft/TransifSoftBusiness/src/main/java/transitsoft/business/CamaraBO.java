/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transitsoft.business;

import java.util.ArrayList;
import transitsoft.dao.CamaraDAO;
import transitsoft.daoImp.CamaraDAOImp;
import transitsoft.model.CamaraDTO;

/**
 *
 * @author USUARIO
 */
public class CamaraBO {

    private final CamaraDAO camaraDao;

    public CamaraBO() {
        this.camaraDao = new CamaraDAOImp();
    }

    public Integer insertar(CamaraDTO camara) {
        if (camara.getModelo() == null || camara.getModelo().trim().isEmpty()) {
            throw new IllegalArgumentException("El modelo de la cámara es obligatorio");
        }
        if (camara.getCodigoSerie() == null || camara.getCodigoSerie().trim().isEmpty()) {
            throw new IllegalArgumentException("El código de serie de la cámara es obligatorio");
        }
        if (camara.getLatitud() == null) {
            throw new IllegalArgumentException("La latitud de la cámara es obligatoria");
        }
        if (camara.getLongitud() == null) {
            throw new IllegalArgumentException("La longitud de la cámara es obligatoria");
        }
        
        return camaraDao.insertar(camara);
    }

    public CamaraDTO obtenerPorId(Integer camaraId) {
        if (camaraId == null || camaraId <= 0) {
            throw new IllegalArgumentException("ID de cámara inválido");
        }
        return camaraDao.obtenerPorId(camaraId);
    }

    public Integer modificar(CamaraDTO camara) {
        if (camara.getId() == null || camara.getId() <= 0) {
            throw new IllegalArgumentException("ID de cámara inválido");
        }
        if (camara.getModelo() == null || camara.getModelo().trim().isEmpty()) {
            throw new IllegalArgumentException("El modelo de la cámara es obligatorio");
        }
        if (camara.getCodigoSerie() == null || camara.getCodigoSerie().trim().isEmpty()) {
            throw new IllegalArgumentException("El código de serie de la cámara es obligatorio");
        }
        return camaraDao.modificar(camara);
    }

    public Integer eliminar(CamaraDTO camara) {
        if (camara.getId() == null || camara.getId() <= 0) {
            throw new IllegalArgumentException("ID de cámara inválido");
        }
        return camaraDao.eliminar(camara);
    }

    public ArrayList<CamaraDTO> listarTodos() {
        return camaraDao.listarTodos();
    }

    public ArrayList<CamaraDTO> buscarPorModelo(String modelo) {
        ArrayList<CamaraDTO> todos = listarTodos();
        ArrayList<CamaraDTO> resultado = new ArrayList<>();
        String modeloBusqueda = modelo.toLowerCase();
        for (CamaraDTO camara : todos) {
            if (camara.getModelo().toLowerCase().contains(modeloBusqueda)) {
                resultado.add(camara);
            }
        }
        return resultado;
    }

    public ArrayList<CamaraDTO> buscarPorCodigoSerie(String codigoSerie) {
        ArrayList<CamaraDTO> todos = listarTodos();
        ArrayList<CamaraDTO> resultado = new ArrayList<>();
        String codigoBusqueda = codigoSerie.toLowerCase();
        for (CamaraDTO camara : todos) {
            if (camara.getCodigoSerie().toLowerCase().contains(codigoBusqueda)) {
                resultado.add(camara);
            }
        }
        return resultado;
    }

    public ArrayList<CamaraDTO> buscarPorZonaGeografica(Integer latMin, Integer latMax, 
                                                          Integer longMin, Integer longMax) {
        ArrayList<CamaraDTO> todos = listarTodos();
        ArrayList<CamaraDTO> resultado = new ArrayList<>();
        for (CamaraDTO camara : todos) {
            if (camara.getLatitud() >= latMin && camara.getLatitud() <= latMax &&
                camara.getLongitud() >= longMin && camara.getLongitud() <= longMax) {
                resultado.add(camara);
            }
        }
        return resultado;
    }
}