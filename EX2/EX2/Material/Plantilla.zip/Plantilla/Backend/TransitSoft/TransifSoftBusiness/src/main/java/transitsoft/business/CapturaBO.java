/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transitsoft.business;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import transitsoft.dao.CapturaDAO;
import transitsoft.daoImp.CapturaDAOImp;
import transitsoft.model.CapturaDTO;
import transitsoft.model.EstadoCaptura;

/**
 *
 * @author USUARIO
 */
public class CapturaBO {

    private final CapturaDAO capturaDao;

    public CapturaBO() {
        this.capturaDao = new CapturaDAOImp();
    }

    public Integer insertar(CapturaDTO captura) {
        if (captura.getCamara() == null || captura.getCamara().getId() == null) {
            throw new IllegalArgumentException("La cámara es obligatoria");
        }
        if (captura.getPlaca() == null || captura.getPlaca().trim().isEmpty()) {
            throw new IllegalArgumentException("La placa es obligatoria");
        }
        if (captura.getVelocidad() == null || captura.getVelocidad() <= 0) {
            throw new IllegalArgumentException("La velocidad debe ser mayor a 0");
        }
        if (captura.getFechaCaptura() == null) {
            throw new IllegalArgumentException("La fecha de captura es obligatoria");
        }
        if (captura.getEstado() == null) {
            captura.setEstado(EstadoCaptura.REGISTRADO);
        }
        return capturaDao.insertar(captura);
    }

    public CapturaDTO obtenerPorId(Integer capturaId) {
        if (capturaId == null || capturaId <= 0) {
            throw new IllegalArgumentException("ID de captura inválido");
        }
        return capturaDao.obtenerPorId(capturaId);
    }

    public Integer modificar(CapturaDTO captura) {
        if (captura.getId() == null || captura.getId() <= 0) {
            throw new IllegalArgumentException("ID de captura inválido");
        }
        return capturaDao.modificar(captura);
    }

    public Integer eliminar(CapturaDTO captura) {
        if (captura.getId() == null || captura.getId() <= 0) {
            throw new IllegalArgumentException("ID de captura inválido");
        }
        return capturaDao.eliminar(captura);
    }

    public ArrayList<CapturaDTO> listarTodos() {
        return capturaDao.listarTodos();
    }

    public List<CapturaDTO> leerTodos() {
        return capturaDao.leerTodos();
    }

    public List<CapturaDTO> obtenerCapturasConExcesoDeVelocidad() {
        List<CapturaDTO> listaTotal = capturaDao.leerTodos();
        List<CapturaDTO> listExceso = new ArrayList<>();
        for (CapturaDTO cap : listaTotal) {
            if (cap.getVelocidad() > 50) {
                listExceso.add(cap);
            }
        }
        return listExceso;
    }

    public List<CapturaDTO> obtenerCapturasConExcesoDeVelocidad(Double limiteVelocidad) {
        List<CapturaDTO> listaTotal = capturaDao.leerTodos();
        List<CapturaDTO> listExceso = new ArrayList<>();
        for (CapturaDTO cap : listaTotal) {
            if (cap.getVelocidad() > limiteVelocidad) {
                listExceso.add(cap);
            }
        }
        return listExceso;
    }

    public void actualizar(CapturaDTO modelo) {
        if (modelo.getId() == null || modelo.getId() <= 0) {
            throw new IllegalArgumentException("ID de captura inválido");
        }
        capturaDao.actualizar(modelo);
    }

    public List<CapturaDTO> buscarPorPlaca(String placa) {
        List<CapturaDTO> todos = leerTodos();
        List<CapturaDTO> resultado = new ArrayList<>();
        String placaBusqueda = placa.toLowerCase();
        for (CapturaDTO captura : todos) {
            if (captura.getPlaca().toLowerCase().contains(placaBusqueda)) {
                resultado.add(captura);
            }
        }
        return resultado;
    }

    public List<CapturaDTO> buscarPorEstado(EstadoCaptura estado) {
        List<CapturaDTO> todos = leerTodos();
        List<CapturaDTO> resultado = new ArrayList<>();
        for (CapturaDTO captura : todos) {
            if (captura.getEstado() == estado) {
                resultado.add(captura);
            }
        }
        return resultado;
    }

    public List<CapturaDTO> buscarPorRangoFechas(Date fechaInicio, Date fechaFin) {
        List<CapturaDTO> todos = leerTodos();
        List<CapturaDTO> resultado = new ArrayList<>();
        for (CapturaDTO captura : todos) {
            Date fechaCaptura = captura.getFechaCaptura();
            if (fechaCaptura != null && 
                !fechaCaptura.before(fechaInicio) && 
                !fechaCaptura.after(fechaFin)) {
                resultado.add(captura);
            }
        }
        return resultado;
    }

    public List<CapturaDTO> buscarPorCamara(Integer camaraId) {
        List<CapturaDTO> todos = leerTodos();
        List<CapturaDTO> resultado = new ArrayList<>();
        for (CapturaDTO captura : todos) {
            if (captura.getCamara() != null && 
                captura.getCamara().getId().equals(camaraId)) {
                resultado.add(captura);
            }
        }
        return resultado;
    }

    public void marcarComoProcesado(Integer capturaId) {
        CapturaDTO captura = obtenerPorId(capturaId);
        if (captura != null) {
            captura.setEstado(EstadoCaptura.PROCESADO);
            actualizar(captura);
        }
    }
}