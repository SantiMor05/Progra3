/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transitsoft.business;

import java.util.ArrayList;
import transitsoft.dao.PropietarioDAO;
import transitsoft.daoImp.PropietarioDAOImp;
import transitsoft.model.PropietarioDTO;

/**
 *
 * @author USUARIO
 */
public class PropietarioBO {

    private final PropietarioDAO propietarioDao;

    public PropietarioBO() {
        this.propietarioDao = new PropietarioDAOImp();
    }

    public Integer insertar(PropietarioDTO propietario) {
        // Validaciones de negocio si son necesarias
        if (propietario.getDni() == null || propietario.getDni().trim().isEmpty()) {
            throw new IllegalArgumentException("El DNI del propietario es obligatorio");
        }
        if (propietario.getNombres() == null || propietario.getNombres().trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre del propietario es obligatorio");
        }
        return propietarioDao.insertar(propietario);
    }

    public PropietarioDTO obtenerPorId(Integer propietarioId) {
        if (propietarioId == null || propietarioId <= 0) {
            throw new IllegalArgumentException("ID de propietario inválido");
        }
        return propietarioDao.obtenerPorId(propietarioId);
    }

    public Integer modificar(PropietarioDTO propietario) {
        if (propietario.getId() == null || propietario.getId() <= 0) {
            throw new IllegalArgumentException("ID de propietario inválido");
        }
        if (propietario.getDni() == null || propietario.getDni().trim().isEmpty()) {
            throw new IllegalArgumentException("El DNI del propietario es obligatorio");
        }
        return propietarioDao.modificar(propietario);
    }

    public Integer eliminar(PropietarioDTO propietario) {
        if (propietario.getId() == null || propietario.getId() <= 0) {
            throw new IllegalArgumentException("ID de propietario inválido");
        }
        return propietarioDao.eliminar(propietario);
    }

    public ArrayList<PropietarioDTO> listarTodos() {
        return propietarioDao.listarTodos();
    }

    public ArrayList<PropietarioDTO> buscarPorDni(String dni) {
        ArrayList<PropietarioDTO> todos = listarTodos();
        ArrayList<PropietarioDTO> resultado = new ArrayList<>();
        for (PropietarioDTO propietario : todos) {
            if (propietario.getDni().contains(dni)) {
                resultado.add(propietario);
            }
        }
        return resultado;
    }

    public ArrayList<PropietarioDTO> buscarPorNombre(String nombre) {
        ArrayList<PropietarioDTO> todos = listarTodos();
        ArrayList<PropietarioDTO> resultado = new ArrayList<>();
        String nombreBusqueda = nombre.toLowerCase();
        for (PropietarioDTO propietario : todos) {
            String nombreCompleto = (propietario.getNombres() + " " + propietario.getApellidos()).toLowerCase();
            if (nombreCompleto.contains(nombreBusqueda)) {
                resultado.add(propietario);
            }
        }
        return resultado;
    }
}