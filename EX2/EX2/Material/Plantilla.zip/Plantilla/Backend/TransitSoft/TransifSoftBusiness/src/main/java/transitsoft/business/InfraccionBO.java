/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transitsoft.business;

import java.util.List;
import java.util.stream.Collectors;
import transitsoft.business.mappers.CapturaToInfraccionMapper;
import transitsoft.model.CapturaDTO;
import java.util.ArrayList;
import java.util.Date;
import transitsoft.dao.InfraccionDAO;
import transitsoft.daoImp.InfraccionDAOImp;
import transitsoft.model.InfraccionDTO;

/**
 *
 * @author USUARIO
 */
public class InfraccionBO {

    private final InfraccionDAO infraccionDao;

    public InfraccionBO() {
        this.infraccionDao = new InfraccionDAOImp();
    }

    public Integer insertar(InfraccionDTO infraccion) {
        if (infraccion.getPlaca() == null || infraccion.getPlaca().trim().isEmpty()) {
            throw new IllegalArgumentException("La placa es obligatoria");
        }
        if (infraccion.getVelocidad() == null || infraccion.getVelocidad() <= 0) {
            throw new IllegalArgumentException("La velocidad debe ser mayor a 0");
        }
        if (infraccion.getLimite() == null || infraccion.getLimite() <= 0) {
            throw new IllegalArgumentException("El límite de velocidad debe ser mayor a 0");
        }
        if (infraccion.getExceso() == null || infraccion.getExceso() < 0) {
            throw new IllegalArgumentException("El exceso de velocidad no puede ser negativo");
        }
        if (infraccion.getMonto() == null || infraccion.getMonto() <= 0) {
            throw new IllegalArgumentException("El monto de la multa debe ser mayor a 0");
        }
        if (infraccion.getFechaCaptura() == null) {
            throw new IllegalArgumentException("La fecha de captura es obligatoria");
        }
        if (infraccion.getFechaRegistro() == null) {
            throw new IllegalArgumentException("La fecha de registro es obligatoria");
        }
        
        return infraccionDao.insertar(infraccion);
    }

    public InfraccionDTO obtenerPorId(Integer infraccionId) {
        if (infraccionId == null || infraccionId <= 0) {
            throw new IllegalArgumentException("ID de infracción inválido");
        }
        return infraccionDao.obtenerPorId(infraccionId);
    }

    public Integer modificar(InfraccionDTO infraccion) {
        if (infraccion.getId() == null || infraccion.getId() <= 0) {
            throw new IllegalArgumentException("ID de infracción inválido");
        }
        if (infraccion.getMonto() == null || infraccion.getMonto() <= 0) {
            throw new IllegalArgumentException("El monto de la multa debe ser mayor a 0");
        }
        return infraccionDao.modificar(infraccion);
    }

    public Integer eliminar(InfraccionDTO infraccion) {
        if (infraccion.getId() == null || infraccion.getId() <= 0) {
            throw new IllegalArgumentException("ID de infracción inválido");
        }
        return infraccionDao.eliminar(infraccion);
    }

    public ArrayList<InfraccionDTO> listarTodos() {
        return infraccionDao.listarTodos();
    }

    public ArrayList<InfraccionDTO> buscarPorPlaca(String placa) {
        ArrayList<InfraccionDTO> todos = listarTodos();
        ArrayList<InfraccionDTO> resultado = new ArrayList<>();
        String placaBusqueda = placa.toLowerCase();
        for (InfraccionDTO infraccion : todos) {
            if (infraccion.getPlaca().toLowerCase().contains(placaBusqueda)) {
                resultado.add(infraccion);
            }
        }
        return resultado;
    }

    public ArrayList<InfraccionDTO> buscarPorRangoFechas(Date fechaInicio, Date fechaFin) {
        ArrayList<InfraccionDTO> todos = listarTodos();
        ArrayList<InfraccionDTO> resultado = new ArrayList<>();
        for (InfraccionDTO infraccion : todos) {
            Date fechaCaptura = infraccion.getFechaCaptura();
            if (fechaCaptura != null && 
                !fechaCaptura.before(fechaInicio) && 
                !fechaCaptura.after(fechaFin)) {
                resultado.add(infraccion);
            }
        }
        return resultado;
    }

    public ArrayList<InfraccionDTO> buscarPorExcesoMayorA(Double excesoMinimo) {
        ArrayList<InfraccionDTO> todos = listarTodos();
        ArrayList<InfraccionDTO> resultado = new ArrayList<>();
        for (InfraccionDTO infraccion : todos) {
            if (infraccion.getExceso() >= excesoMinimo) {
                resultado.add(infraccion);
            }
        }
        return resultado;
    }

    public ArrayList<InfraccionDTO> buscarPorCamara(Integer camaraId) {
        ArrayList<InfraccionDTO> todos = listarTodos();
        ArrayList<InfraccionDTO> resultado = new ArrayList<>();
        for (InfraccionDTO infraccion : todos) {
            if (infraccion.getCamaraId() != null && 
                infraccion.getCamaraId().equals(camaraId)) {
                resultado.add(infraccion);
            }
        }
        return resultado;
    }

    public Double calcularMontoTotal() {
        ArrayList<InfraccionDTO> todos = listarTodos();
        Double total = 0.0;
        for (InfraccionDTO infraccion : todos) {
            if (infraccion.getMonto() != null) {
                total += infraccion.getMonto();
            }
        }
        return total;
    }

    public Double calcularMontoTotalPorPlaca(String placa) {
        ArrayList<InfraccionDTO> infracciones = buscarPorPlaca(placa);
        Double total = 0.0;
        for (InfraccionDTO infraccion : infracciones) {
            if (infraccion.getMonto() != null) {
                total += infraccion.getMonto();
            }
        }
        return total;
    }
    
    ////////////////////////////////
    
    
    public List<InfraccionDTO> crearInfracciones(List<CapturaDTO> capturasConExceso) {
        var mapper = new CapturaToInfraccionMapper();
        return capturasConExceso.stream().map(mapper::map).collect(Collectors.toList());
    }
}
