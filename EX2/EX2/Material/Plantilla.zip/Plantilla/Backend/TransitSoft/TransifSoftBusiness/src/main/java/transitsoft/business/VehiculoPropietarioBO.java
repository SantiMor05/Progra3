/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transitsoft.business;

import java.util.ArrayList;
import transitsoft.dao.VehiculoPropietarioDAO;
import transitsoft.daoImp.VehiculoPropietarioDAOImp;
import transitsoft.model.VehiculoPropietarioDTO;

/**
 *
 * @author USUARIO
 */
public class VehiculoPropietarioBO {

    private final VehiculoPropietarioDAO vehiculoPropietarioDao;

    public VehiculoPropietarioBO() {
        this.vehiculoPropietarioDao = new VehiculoPropietarioDAOImp();
    }

    public Integer insertar(VehiculoPropietarioDTO vehiculoPropietario) {
        if (vehiculoPropietario.getVehiculo() == null || 
            vehiculoPropietario.getVehiculo().getId() == null || 
            vehiculoPropietario.getVehiculo().getId() <= 0) {
            throw new IllegalArgumentException("El vehículo es obligatorio");
        }
        if (vehiculoPropietario.getPropietario() == null || 
            vehiculoPropietario.getPropietario().getId() == null || 
            vehiculoPropietario.getPropietario().getId() <= 0) {
            throw new IllegalArgumentException("El propietario es obligatorio");
        }
        return vehiculoPropietarioDao.insertar(vehiculoPropietario);
    }

    public VehiculoPropietarioDTO obtenerPorId(Integer vehiculoPropietarioId) {
        if (vehiculoPropietarioId == null || vehiculoPropietarioId <= 0) {
            throw new IllegalArgumentException("ID de relación vehículo-propietario inválido");
        }
        return vehiculoPropietarioDao.obtenerPorId(vehiculoPropietarioId);
    }

    public Integer modificar(VehiculoPropietarioDTO vehiculoPropietario) {
        if (vehiculoPropietario.getId() == null || vehiculoPropietario.getId() <= 0) {
            throw new IllegalArgumentException("ID de relación vehículo-propietario inválido");
        }
        if (vehiculoPropietario.getVehiculo() == null || 
            vehiculoPropietario.getVehiculo().getId() == null) {
            throw new IllegalArgumentException("El vehículo es obligatorio");
        }
        if (vehiculoPropietario.getPropietario() == null || 
            vehiculoPropietario.getPropietario().getId() == null) {
            throw new IllegalArgumentException("El propietario es obligatorio");
        }
        return vehiculoPropietarioDao.modificar(vehiculoPropietario);
    }

    public Integer eliminar(VehiculoPropietarioDTO vehiculoPropietario) {
        if (vehiculoPropietario.getId() == null || vehiculoPropietario.getId() <= 0) {
            throw new IllegalArgumentException("ID de relación vehículo-propietario inválido");
        }
        return vehiculoPropietarioDao.eliminar(vehiculoPropietario);
    }

    public ArrayList<VehiculoPropietarioDTO> listarTodos() {
        return vehiculoPropietarioDao.listarTodos();
    }

    public ArrayList<VehiculoPropietarioDTO> buscarPorVehiculoId(Integer vehiculoId) {
        ArrayList<VehiculoPropietarioDTO> todos = listarTodos();
        ArrayList<VehiculoPropietarioDTO> resultado = new ArrayList<>();
        for (VehiculoPropietarioDTO vp : todos) {
            if (vp.getVehiculo() != null && 
                vp.getVehiculo().getId().equals(vehiculoId)) {
                resultado.add(vp);
            }
        }
        return resultado;
    }

    public ArrayList<VehiculoPropietarioDTO> buscarPorPropietarioId(Integer propietarioId) {
        ArrayList<VehiculoPropietarioDTO> todos = listarTodos();
        ArrayList<VehiculoPropietarioDTO> resultado = new ArrayList<>();
        for (VehiculoPropietarioDTO vp : todos) {
            if (vp.getPropietario() != null && 
                vp.getPropietario().getId().equals(propietarioId)) {
                resultado.add(vp);
            }
        }
        return resultado;
    }

    public ArrayList<VehiculoPropietarioDTO> buscarPorPlaca(String placa) {
        ArrayList<VehiculoPropietarioDTO> todos = listarTodos();
        ArrayList<VehiculoPropietarioDTO> resultado = new ArrayList<>();
        String placaBusqueda = placa.toLowerCase();
        for (VehiculoPropietarioDTO vp : todos) {
            if (vp.getVehiculo() != null && 
                vp.getVehiculo().getPlaca() != null &&
                vp.getVehiculo().getPlaca().toLowerCase().contains(placaBusqueda)) {
                resultado.add(vp);
            }
        }
        return resultado;
    }
}