/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transitsoft.business;

import java.util.ArrayList;
import java.util.Calendar;
import transitsoft.dao.VehiculoDAO;
import transitsoft.daoImp.VehiculoDAOImp;
import transitsoft.model.VehiculoDTO;

/**
 *
 * @author USUARIO
 */
public class VehiculoBO {

    private final VehiculoDAO vehiculoDao;

    public VehiculoBO() {
        this.vehiculoDao = new VehiculoDAOImp();
    }

    public Integer insertar(VehiculoDTO vehiculo) {
        if (vehiculo.getPlaca() == null || vehiculo.getPlaca().trim().isEmpty()) {
            throw new IllegalArgumentException("La placa del vehículo es obligatoria");
        }
        if (vehiculo.getMarca() == null || vehiculo.getMarca().trim().isEmpty()) {
            throw new IllegalArgumentException("La marca del vehículo es obligatoria");
        }
        if (vehiculo.getAnho() == null || vehiculo.getAnho() <= 0) {
            throw new IllegalArgumentException("El año del vehículo es inválido");
        }
        
        int anioActual = Calendar.getInstance().get(Calendar.YEAR);
        if (vehiculo.getAnho() > anioActual) {
            throw new IllegalArgumentException("El año del vehículo no puede ser mayor al año actual");
        }
        
        return vehiculoDao.insertar(vehiculo);
    }

    public VehiculoDTO obtenerPorId(Integer vehiculoId) {
        if (vehiculoId == null || vehiculoId <= 0) {
            throw new IllegalArgumentException("ID de vehículo inválido");
        }
        return vehiculoDao.obtenerPorId(vehiculoId);
    }

    public Integer modificar(VehiculoDTO vehiculo) {
        if (vehiculo.getId() == null || vehiculo.getId() <= 0) {
            throw new IllegalArgumentException("ID de vehículo inválido");
        }
        if (vehiculo.getPlaca() == null || vehiculo.getPlaca().trim().isEmpty()) {
            throw new IllegalArgumentException("La placa del vehículo es obligatoria");
        }
        return vehiculoDao.modificar(vehiculo);
    }

    public Integer eliminar(VehiculoDTO vehiculo) {
        if (vehiculo.getId() == null || vehiculo.getId() <= 0) {
            throw new IllegalArgumentException("ID de vehículo inválido");
        }
        return vehiculoDao.eliminar(vehiculo);
    }

    public ArrayList<VehiculoDTO> listarTodos() {
        return vehiculoDao.listarTodos();
    }

    public ArrayList<VehiculoDTO> buscarPorPlaca(String placa) {
        ArrayList<VehiculoDTO> todos = listarTodos();
        ArrayList<VehiculoDTO> resultado = new ArrayList<>();
        String placaBusqueda = placa.toLowerCase();
        for (VehiculoDTO vehiculo : todos) {
            if (vehiculo.getPlaca().toLowerCase().contains(placaBusqueda)) {
                resultado.add(vehiculo);
            }
        }
        return resultado;
    }

    public ArrayList<VehiculoDTO> buscarPorMarca(String marca) {
        ArrayList<VehiculoDTO> todos = listarTodos();
        ArrayList<VehiculoDTO> resultado = new ArrayList<>();
        String marcaBusqueda = marca.toLowerCase();
        for (VehiculoDTO vehiculo : todos) {
            if (vehiculo.getMarca().toLowerCase().contains(marcaBusqueda)) {
                resultado.add(vehiculo);
            }
        }
        return resultado;
    }

    public ArrayList<VehiculoDTO> buscarPorAnio(Integer anio) {
        ArrayList<VehiculoDTO> todos = listarTodos();
        ArrayList<VehiculoDTO> resultado = new ArrayList<>();
        for (VehiculoDTO vehiculo : todos) {
            if (vehiculo.getAnho().equals(anio)) {
                resultado.add(vehiculo);
            }
        }
        return resultado;
    }
}