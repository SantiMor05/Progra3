package pe.edu.pucp.transitsoft.services;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import transitsoft.business.VehiculoBO;
import transitsoft.model.VehiculoDTO;

/**
 *
 * @author USUARIO
 */
@Path("vehiculos")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class VehiculoService {
    
    private VehiculoBO vehiculoBO;
    
    public VehiculoService() {
        this.vehiculoBO = new VehiculoBO();
    }
    
    @POST
    public Response insertar(VehiculoDTO vehiculoDTO) {
        try {
            Integer respuesta = this.vehiculoBO.insertar(vehiculoDTO);
            if (respuesta == 0)
                return Response.status(Response.Status.NOT_ACCEPTABLE).build();
            vehiculoDTO.setId(respuesta);
            return Response.status(Response.Status.CREATED).entity(vehiculoDTO).build();
        } catch (IllegalArgumentException e) {
            return Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
        }
    }
    
    @PUT
    public Response modificar(VehiculoDTO vehiculoDTO) {
        try {
            Integer respuesta = this.vehiculoBO.modificar(vehiculoDTO);
            if (respuesta == 0)
                return Response.status(Response.Status.NOT_MODIFIED).build();
            return Response.ok(vehiculoDTO).build();
        } catch (IllegalArgumentException e) {
            return Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
        }
    }
    
    @DELETE
    @Path("{id}")
    public Response eliminar(@PathParam("id") Integer vehiculoId) {
        try {
            VehiculoDTO vehiculo = new VehiculoDTO();
            vehiculo.setId(vehiculoId);
            Integer respuesta = this.vehiculoBO.eliminar(vehiculo);
            if (respuesta > 0)
                return Response.noContent().build();
            return Response.status(Response.Status.NOT_FOUND).build();
        } catch (IllegalArgumentException e) {
            return Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
        }
    }
    
    @GET
    public ArrayList<VehiculoDTO> listarTodos() {
        return this.vehiculoBO.listarTodos();
    }
    
    @GET
    @Path("{id}")
    public Response obtenerPorId(@PathParam("id") Integer vehiculoId) {
        try {
            VehiculoDTO vehiculo = this.vehiculoBO.obtenerPorId(vehiculoId);
            if (vehiculo == null || vehiculo.getId() == null) {
                return Response.status(Response.Status.NOT_FOUND).build();
            }
            return Response.ok(vehiculo).build();
        } catch (IllegalArgumentException e) {
            return Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
        }
    }
    
    @GET
    @Path("buscar/placa")
    public Response buscarPorPlaca(@QueryParam("placa") String placa) {
        if (placa == null || placa.trim().isEmpty()) {
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity("La placa es obligatoria").build();
        }
        ArrayList<VehiculoDTO> resultado = this.vehiculoBO.buscarPorPlaca(placa);
        return Response.ok(resultado).build();
    }
    
    @GET
    @Path("buscar/marca")
    public Response buscarPorMarca(@QueryParam("marca") String marca) {
        if (marca == null || marca.trim().isEmpty()) {
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity("La marca es obligatoria").build();
        }
        ArrayList<VehiculoDTO> resultado = this.vehiculoBO.buscarPorMarca(marca);
        return Response.ok(resultado).build();
    }
    
    @GET
    @Path("buscar/anio/{anio}")
    public Response buscarPorAnio(@PathParam("anio") Integer anio) {
        if (anio == null || anio <= 0) {
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity("El año es inválido").build();
        }
        ArrayList<VehiculoDTO> resultado = this.vehiculoBO.buscarPorAnio(anio);
        return Response.ok(resultado).build();
    }
}