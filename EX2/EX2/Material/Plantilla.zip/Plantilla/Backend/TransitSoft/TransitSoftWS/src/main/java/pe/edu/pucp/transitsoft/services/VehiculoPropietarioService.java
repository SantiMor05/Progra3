package pe.edu.pucp.transitsoft.services;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import transitsoft.business.VehiculoPropietarioBO;
import transitsoft.model.VehiculoPropietarioDTO;

/**
 *
 * @author USUARIO
 */
@Path("vehiculo-propietarios")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class VehiculoPropietarioService {
    
    private VehiculoPropietarioBO vehiculoPropietarioBO;
    
    public VehiculoPropietarioService() {
        this.vehiculoPropietarioBO = new VehiculoPropietarioBO();
    }
    
    @POST
    public Response insertar(VehiculoPropietarioDTO vehiculoPropietarioDTO) {
        try {
            Integer respuesta = this.vehiculoPropietarioBO.insertar(vehiculoPropietarioDTO);
            if (respuesta == 0)
                return Response.status(Response.Status.NOT_ACCEPTABLE).build();
            vehiculoPropietarioDTO.setId(respuesta);
            return Response.status(Response.Status.CREATED).entity(vehiculoPropietarioDTO).build();
        } catch (IllegalArgumentException e) {
            return Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
        }
    }
    
    @PUT
    public Response modificar(VehiculoPropietarioDTO vehiculoPropietarioDTO) {
        try {
            Integer respuesta = this.vehiculoPropietarioBO.modificar(vehiculoPropietarioDTO);
            if (respuesta == 0)
                return Response.status(Response.Status.NOT_MODIFIED).build();
            return Response.ok(vehiculoPropietarioDTO).build();
        } catch (IllegalArgumentException e) {
            return Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
        }
    }
    
    @DELETE
    @Path("{id}")
    public Response eliminar(@PathParam("id") Integer vehiculoPropietarioId) {
        try {
            VehiculoPropietarioDTO vehiculoPropietario = new VehiculoPropietarioDTO();
            vehiculoPropietario.setId(vehiculoPropietarioId);
            Integer respuesta = this.vehiculoPropietarioBO.eliminar(vehiculoPropietario);
            if (respuesta > 0)
                return Response.noContent().build();
            return Response.status(Response.Status.NOT_FOUND).build();
        } catch (IllegalArgumentException e) {
            return Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
        }
    }
    
    @GET
    public ArrayList<VehiculoPropietarioDTO> listarTodos() {
        return this.vehiculoPropietarioBO.listarTodos();
    }
    
    @GET
    @Path("{id}")
    public Response obtenerPorId(@PathParam("id") Integer vehiculoPropietarioId) {
        try {
            VehiculoPropietarioDTO vehiculoPropietario = this.vehiculoPropietarioBO.obtenerPorId(vehiculoPropietarioId);
            if (vehiculoPropietario == null || vehiculoPropietario.getId() == null) {
                return Response.status(Response.Status.NOT_FOUND).build();
            }
            return Response.ok(vehiculoPropietario).build();
        } catch (IllegalArgumentException e) {
            return Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
        }
    }
    
    @GET
    @Path("buscar/vehiculo/{vehiculoId}")
    public Response buscarPorVehiculoId(@PathParam("vehiculoId") Integer vehiculoId) {
        if (vehiculoId == null || vehiculoId <= 0) {
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity("El ID del vehículo es inválido").build();
        }
        ArrayList<VehiculoPropietarioDTO> resultado = this.vehiculoPropietarioBO.buscarPorVehiculoId(vehiculoId);
        return Response.ok(resultado).build();
    }
    
    @GET
    @Path("buscar/propietario/{propietarioId}")
    public Response buscarPorPropietarioId(@PathParam("propietarioId") Integer propietarioId) {
        if (propietarioId == null || propietarioId <= 0) {
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity("El ID del propietario es inválido").build();
        }
        ArrayList<VehiculoPropietarioDTO> resultado = this.vehiculoPropietarioBO.buscarPorPropietarioId(propietarioId);
        return Response.ok(resultado).build();
    }
    
    @GET
    @Path("buscar/placa")
    public Response buscarPorPlaca(@QueryParam("placa") String placa) {
        if (placa == null || placa.trim().isEmpty()) {
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity("La placa es obligatoria").build();
        }
        ArrayList<VehiculoPropietarioDTO> resultado = this.vehiculoPropietarioBO.buscarPorPlaca(placa);
        return Response.ok(resultado).build();
    }
}