package pe.edu.pucp.transitsoft.services;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import transitsoft.business.PropietarioBO;
import transitsoft.model.PropietarioDTO;

/**
 *
 * @author USUARIO
 */
@Path("propietarios")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class PropietarioService {
    
    private PropietarioBO propietarioBO;
    
    public PropietarioService() {
        this.propietarioBO = new PropietarioBO();
    }
    
    @POST
    public Response insertar(PropietarioDTO propietarioDTO) {
        try {
            Integer respuesta = this.propietarioBO.insertar(propietarioDTO);
            if (respuesta == 0)
                return Response.status(Response.Status.NOT_ACCEPTABLE).build();
            propietarioDTO.setId(respuesta);
            return Response.status(Response.Status.CREATED).entity(propietarioDTO).build();
        } catch (IllegalArgumentException e) {
            return Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
        }
    }
    
    @PUT
    public Response modificar(PropietarioDTO propietarioDTO) {
        try {
            Integer respuesta = this.propietarioBO.modificar(propietarioDTO);
            if (respuesta == 0)
                return Response.status(Response.Status.NOT_MODIFIED).build();
            return Response.ok(propietarioDTO).build();
        } catch (IllegalArgumentException e) {
            return Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
        }
    }
    
    @DELETE
    @Path("{id}")
    public Response eliminar(@PathParam("id") Integer propietarioId) {
        try {
            PropietarioDTO propietario = new PropietarioDTO();
            propietario.setId(propietarioId);
            Integer respuesta = this.propietarioBO.eliminar(propietario);
            if (respuesta > 0)
                return Response.noContent().build();
            return Response.status(Response.Status.NOT_FOUND).build();
        } catch (IllegalArgumentException e) {
            return Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
        }
    }
    
    @GET
    public ArrayList<PropietarioDTO> listarTodos() {
        return this.propietarioBO.listarTodos();
    }
    
    @GET
    @Path("{id}")
    public Response obtenerPorId(@PathParam("id") Integer propietarioId) {
        try {
            PropietarioDTO propietario = this.propietarioBO.obtenerPorId(propietarioId);
            if (propietario == null || propietario.getId() == null) {
                return Response.status(Response.Status.NOT_FOUND).build();
            }
            return Response.ok(propietario).build();
        } catch (IllegalArgumentException e) {
            return Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
        }
    }
    
    @GET
    @Path("buscar/dni")
    public Response buscarPorDni(@QueryParam("dni") String dni) {
        if (dni == null || dni.trim().isEmpty()) {
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity("El DNI es obligatorio").build();
        }
        ArrayList<PropietarioDTO> resultado = this.propietarioBO.buscarPorDni(dni);
        return Response.ok(resultado).build();
    }
    
    @GET
    @Path("buscar/nombre")
    public Response buscarPorNombre(@QueryParam("nombre") String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity("El nombre es obligatorio").build();
        }
        ArrayList<PropietarioDTO> resultado = this.propietarioBO.buscarPorNombre(nombre);
        return Response.ok(resultado).build();
    }
}