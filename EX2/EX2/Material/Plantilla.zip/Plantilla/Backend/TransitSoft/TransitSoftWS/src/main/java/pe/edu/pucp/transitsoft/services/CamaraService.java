package pe.edu.pucp.transitsoft.services;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import transitsoft.business.CamaraBO;
import transitsoft.model.CamaraDTO;

/**
 *
 * @author USUARIO
 */
@Path("camaras")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class CamaraService {
    
    private CamaraBO camaraBO;
    
    public CamaraService() {
        this.camaraBO = new CamaraBO();
    }
    
    @POST
    public Response insertar(CamaraDTO camaraDTO) {
        try {
            Integer respuesta = this.camaraBO.insertar(camaraDTO);
            if (respuesta == 0)
                return Response.status(Response.Status.NOT_ACCEPTABLE).build();
            camaraDTO.setId(respuesta);
            return Response.status(Response.Status.CREATED).entity(camaraDTO).build();
        } catch (IllegalArgumentException e) {
            return Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
        }
    }
    
    @PUT
    public Response modificar(CamaraDTO camaraDTO) {
        try {
            Integer respuesta = this.camaraBO.modificar(camaraDTO);
            if (respuesta == 0)
                return Response.status(Response.Status.NOT_MODIFIED).build();
            return Response.ok(camaraDTO).build();
        } catch (IllegalArgumentException e) {
            return Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
        }
    }
    
    @DELETE
    @Path("{id}")
    public Response eliminar(@PathParam("id") Integer camaraId) {
        try {
            CamaraDTO camara = new CamaraDTO();
            camara.setId(camaraId);
            Integer respuesta = this.camaraBO.eliminar(camara);
            if (respuesta > 0)
                return Response.noContent().build();
            return Response.status(Response.Status.NOT_FOUND).build();
        } catch (IllegalArgumentException e) {
            return Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
        }
    }
    
    @GET
    public ArrayList<CamaraDTO> listarTodos() {
        return this.camaraBO.listarTodos();
    }
    
    @GET
    @Path("{id}")
    public Response obtenerPorId(@PathParam("id") Integer camaraId) {
        try {
            CamaraDTO camara = this.camaraBO.obtenerPorId(camaraId);
            if (camara == null || camara.getId() == null) {
                return Response.status(Response.Status.NOT_FOUND).build();
            }
            return Response.ok(camara).build();
        } catch (IllegalArgumentException e) {
            return Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
        }
    }
    
    @GET
    @Path("buscar/modelo")
    public Response buscarPorModelo(@QueryParam("modelo") String modelo) {
        if (modelo == null || modelo.trim().isEmpty()) {
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity("El modelo es obligatorio").build();
        }
        ArrayList<CamaraDTO> resultado = this.camaraBO.buscarPorModelo(modelo);
        return Response.ok(resultado).build();
    }
    
    @GET
    @Path("buscar/codigo-serie")
    public Response buscarPorCodigoSerie(@QueryParam("codigoSerie") String codigoSerie) {
        if (codigoSerie == null || codigoSerie.trim().isEmpty()) {
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity("El código de serie es obligatorio").build();
        }
        ArrayList<CamaraDTO> resultado = this.camaraBO.buscarPorCodigoSerie(codigoSerie);
        return Response.ok(resultado).build();
    }
    
    @GET
    @Path("buscar/zona")
    public Response buscarPorZonaGeografica(
            @QueryParam("latMin") Integer latMin,
            @QueryParam("latMax") Integer latMax,
            @QueryParam("longMin") Integer longMin,
            @QueryParam("longMax") Integer longMax) {
        
        if (latMin == null || latMax == null || longMin == null || longMax == null) {
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity("Todos los parámetros de zona son obligatorios").build();
        }
        ArrayList<CamaraDTO> resultado = this.camaraBO.buscarPorZonaGeografica(latMin, latMax, longMin, longMax);
        return Response.ok(resultado).build();
    }
}