package pe.edu.pucp.transitsoft.services;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import transitsoft.business.CapturaBO;
import transitsoft.model.CapturaDTO;
import transitsoft.model.EstadoCaptura;

/**
 *
 * @author USUARIO
 */
@Path("capturas")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class CapturaService {
    
    private CapturaBO capturaBO;
    
    public CapturaService() {
        this.capturaBO = new CapturaBO();
    }
    
    @POST
    public Response insertar(CapturaDTO capturaDTO) {
        try {
            Integer respuesta = this.capturaBO.insertar(capturaDTO);
            if (respuesta == 0)
                return Response.status(Response.Status.NOT_ACCEPTABLE).build();
            capturaDTO.setId(respuesta);
            return Response.status(Response.Status.CREATED).entity(capturaDTO).build();
        } catch (IllegalArgumentException e) {
            return Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
        }
    }
    
    @PUT
    public Response modificar(CapturaDTO capturaDTO) {
        try {
            Integer respuesta = this.capturaBO.modificar(capturaDTO);
            if (respuesta == 0)
                return Response.status(Response.Status.NOT_MODIFIED).build();
            return Response.ok(capturaDTO).build();
        } catch (IllegalArgumentException e) {
            return Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
        }
    }
    
    @PUT
    @Path("actualizar")
    public Response actualizar(CapturaDTO capturaDTO) {
        try {
            this.capturaBO.actualizar(capturaDTO);
            return Response.ok(capturaDTO).build();
        } catch (IllegalArgumentException e) {
            return Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
        }
    }
    
    @DELETE
    @Path("{id}")
    public Response eliminar(@PathParam("id") Integer capturaId) {
        try {
            CapturaDTO captura = new CapturaDTO();
            captura.setId(capturaId);
            Integer respuesta = this.capturaBO.eliminar(captura);
            if (respuesta > 0)
                return Response.noContent().build();
            return Response.status(Response.Status.NOT_FOUND).build();
        } catch (IllegalArgumentException e) {
            return Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
        }
    }
    
    @GET
    public ArrayList<CapturaDTO> listarTodos() {
        return this.capturaBO.listarTodos();
    }
    
    @GET
    @Path("leer-todos")
    public List<CapturaDTO> leerTodos() {
        return this.capturaBO.leerTodos();
    }
    
    @GET
    @Path("{id}")
    public Response obtenerPorId(@PathParam("id") Integer capturaId) {
        try {
            CapturaDTO captura = this.capturaBO.obtenerPorId(capturaId);
            if (captura == null || captura.getId() == null) {
                return Response.status(Response.Status.NOT_FOUND).build();
            }
            return Response.ok(captura).build();
        } catch (IllegalArgumentException e) {
            return Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
        }
    }
    
    @GET
    @Path("exceso-velocidad")
    public List<CapturaDTO> obtenerCapturasConExcesoDeVelocidad() {
        return this.capturaBO.obtenerCapturasConExcesoDeVelocidad();
    }
    
    @GET
    @Path("exceso-velocidad/{limite}")
    public List<CapturaDTO> obtenerCapturasConExcesoDeVelocidadConLimite(@PathParam("limite") Double limite) {
        return this.capturaBO.obtenerCapturasConExcesoDeVelocidad(limite);
    }
    
    @GET
    @Path("buscar/placa")
    public Response buscarPorPlaca(@QueryParam("placa") String placa) {
        if (placa == null || placa.trim().isEmpty()) {
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity("La placa es obligatoria").build();
        }
        List<CapturaDTO> resultado = this.capturaBO.buscarPorPlaca(placa);
        return Response.ok(resultado).build();
    }
    
    @GET
    @Path("buscar/estado/{estado}")
    public Response buscarPorEstado(@PathParam("estado") String estado) {
        try {
            EstadoCaptura estadoCaptura = EstadoCaptura.valueOf(estado.toUpperCase());
            List<CapturaDTO> resultado = this.capturaBO.buscarPorEstado(estadoCaptura);
            return Response.ok(resultado).build();
        } catch (IllegalArgumentException e) {
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity("Estado inválido. Use: REGISTRADO o PROCESADO").build();
        }
    }
    
    @GET
    @Path("buscar/fechas")
    public Response buscarPorRangoFechas(
            @QueryParam("fechaInicio") String fechaInicio,
            @QueryParam("fechaFin") String fechaFin) {
        
        if (fechaInicio == null || fechaFin == null) {
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity("Las fechas de inicio y fin son obligatorias").build();
        }
        
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date inicio = sdf.parse(fechaInicio);
            Date fin = sdf.parse(fechaFin);
            List<CapturaDTO> resultado = this.capturaBO.buscarPorRangoFechas(inicio, fin);
            return Response.ok(resultado).build();
        } catch (ParseException e) {
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity("Formato de fecha inválido. Use: yyyy-MM-dd").build();
        }
    }
    
    @GET
    @Path("buscar/camara/{camaraId}")
    public Response buscarPorCamara(@PathParam("camaraId") Integer camaraId) {
        if (camaraId == null || camaraId <= 0) {
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity("El ID de la cámara es inválido").build();
        }
        List<CapturaDTO> resultado = this.capturaBO.buscarPorCamara(camaraId);
        return Response.ok(resultado).build();
    }
    
    @PUT
    @Path("marcar-procesado/{id}")
    public Response marcarComoProcesado(@PathParam("id") Integer capturaId) {
        try {
            this.capturaBO.marcarComoProcesado(capturaId);
            return Response.ok().entity("Captura marcada como procesada").build();
        } catch (IllegalArgumentException e) {
            return Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
        } catch (Exception e) {
            return Response.status(Response.Status.NOT_FOUND)
                    .entity("Captura no encontrada").build();
        }
    }
}