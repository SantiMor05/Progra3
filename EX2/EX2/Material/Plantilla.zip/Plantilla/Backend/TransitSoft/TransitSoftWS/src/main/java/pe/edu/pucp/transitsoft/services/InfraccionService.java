package pe.edu.pucp.transitsoft.services;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import transitsoft.business.InfraccionBO;
import transitsoft.model.InfraccionDTO;

/**
 *
 * @author USUARIO
 */
@Path("infracciones")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class InfraccionService {

    private InfraccionBO infraccionBO;

    public InfraccionService() {
        this.infraccionBO = new InfraccionBO();
    }

    @POST
    public Response insertar(InfraccionDTO infraccionDTO) {
        try {
            Integer respuesta = this.infraccionBO.insertar(infraccionDTO);
            if (respuesta == 0) {
                return Response.status(Response.Status.NOT_ACCEPTABLE).build();
            }
            infraccionDTO.setId(respuesta);
            return Response.status(Response.Status.CREATED).entity(infraccionDTO).build();
        } catch (IllegalArgumentException e) {
            return Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
        }
    }

    @PUT
    public Response modificar(InfraccionDTO infraccionDTO) {
        try {
            Integer respuesta = this.infraccionBO.modificar(infraccionDTO);
            if (respuesta == 0) {
                return Response.status(Response.Status.NOT_MODIFIED).build();
            }
            return Response.ok(infraccionDTO).build();
        } catch (IllegalArgumentException e) {
            return Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
        }
    }

    @DELETE
    @Path("{id}")
    public Response eliminar(@PathParam("id") Integer infraccionId) {
        try {
            InfraccionDTO infraccion = new InfraccionDTO();
            infraccion.setId(infraccionId);
            Integer respuesta = this.infraccionBO.eliminar(infraccion);
            if (respuesta > 0) {
                return Response.noContent().build();
            }
            return Response.status(Response.Status.NOT_FOUND).build();
        } catch (IllegalArgumentException e) {
            return Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
        }
    }

    @GET
    public ArrayList<InfraccionDTO> listarTodos() {
        return this.infraccionBO.listarTodos();
    }

    @GET
    @Path("{id}")
    public Response obtenerPorId(@PathParam("id") Integer infraccionId) {
        try {
            InfraccionDTO infraccion = this.infraccionBO.obtenerPorId(infraccionId);
            if (infraccion == null || infraccion.getId() == null) {
                return Response.status(Response.Status.NOT_FOUND).build();
            }
            return Response.ok(infraccion).build();
        } catch (IllegalArgumentException e) {
            return Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
        }
    }

    @GET
    @Path("buscar/placa")
    public Response buscarPorPlaca(@QueryParam("placa") String placa) {
        if (placa == null || placa.trim().isEmpty()) {
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity("La placa es obligatoria").build();
        }
        ArrayList<InfraccionDTO> resultado = this.infraccionBO.buscarPorPlaca(placa);
        return Response.ok(resultado).build();
    }

    @GET
    @Path("buscar/fechas")
    public Response buscarPorRangoFechas(
            @QueryParam("fechaInicio") String fechaInicio,
            @QueryParam("fechaFin") String fechaFin) {

        if (fechaInicio == null || fechaFin == null) {
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity("Las fechas de inicio y fin son obligatorias").build();
        }

        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date inicio = sdf.parse(fechaInicio);
            Date fin = sdf.parse(fechaFin);
            ArrayList<InfraccionDTO> resultado = this.infraccionBO.buscarPorRangoFechas(inicio, fin);
            return Response.ok(resultado).build();
        } catch (ParseException e) {
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity("Formato de fecha inválido. Use: yyyy-MM-dd").build();
        }
    }

    @GET
    @Path("buscar/exceso/{excesoMinimo}")
    public Response buscarPorExcesoMayorA(@PathParam("excesoMinimo") Double excesoMinimo) {
        if (excesoMinimo == null || excesoMinimo < 0) {
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity("El exceso mínimo debe ser mayor o igual a 0").build();
        }
        ArrayList<InfraccionDTO> resultado = this.infraccionBO.buscarPorExcesoMayorA(excesoMinimo);
        return Response.ok(resultado).build();
    }

    @GET
    @Path("buscar/camara/{camaraId}")
    public Response buscarPorCamara(@PathParam("camaraId") Integer camaraId) {
        if (camaraId == null || camaraId <= 0) {
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity("El ID de la cámara es inválido").build();
        }
        ArrayList<InfraccionDTO> resultado = this.infraccionBO.buscarPorCamara(camaraId);
        return Response.ok(resultado).build();
    }

    @GET
    @Path("monto-total")
    public Response calcularMontoTotal() {
        Double total = this.infraccionBO.calcularMontoTotal();
        return Response.ok().entity("{\"montoTotal\": " + total + "}").build();
    }

    @GET
    @Path("monto-total/placa")
    public Response calcularMontoTotalPorPlaca(@QueryParam("placa") String placa) {
        if (placa == null || placa.trim().isEmpty()) {
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity("La placa es obligatoria").build();
        }
        Double total = this.infraccionBO.calcularMontoTotalPorPlaca(placa);
        return Response.ok().entity("{\"placa\": \"" + placa + "\", \"montoTotal\": " + total + "}").build();
    }
}
