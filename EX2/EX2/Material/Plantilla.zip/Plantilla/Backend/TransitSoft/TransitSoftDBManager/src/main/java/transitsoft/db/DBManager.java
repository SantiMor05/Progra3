/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transitsoft.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;
import transitsoft.db.util.Cifrado;

public abstract class DBManager {

    protected static final String ARCHIVO_CONFIGURACION = "jdbc.properties";    

    // Este campo es privado y solo se usa dentro de getConnection()
    private Connection conexion;
    protected String driver;
    protected String tipo_de_driver;
    protected String base_de_datos;
    protected String nombre_de_host;
    protected String puerto;
    protected String usuario;
    protected String contraseña;
    
    // Las dos instancias estáticas (Singleton)
    private static DBManager dbManagerMYSQL = null;
    private static DBManager dbManagerMSSQL = null;

    protected DBManager() {
        // Constructor protegido para implementar el patrón Singletón
    }

    // Patrón Factory para obtener la instancia correcta
    public static DBManager getInstance(String tipo) {
        
        if(tipo.equals("MYSQL")){
            if (DBManager.dbManagerMYSQL == null) {    
                DBManager.createInstance(tipo);
            }
            return DBManager.dbManagerMYSQL;
        }
        else{ // Asume MSSQL para cualquier otro valor
            if(DBManager.dbManagerMSSQL == null){
                DBManager.createInstance(tipo);
            }
            return DBManager.dbManagerMSSQL;
        }
    }

    // Método privado para crear la instancia (Factory)
    private static void createInstance(String tipo) {
        if(tipo.equals("MYSQL")){
            if (DBManager.dbManagerMYSQL == null){
                DBManager.dbManagerMYSQL = new DBManagerMySQL();
                DBManager.dbManagerMYSQL.leer_archivo_de_propiedades();
            }
        }
        else{ // Asume MSSQL
            if(DBManager.dbManagerMSSQL == null) {
                DBManager.dbManagerMSSQL = new DBManagerMSSQL();
                DBManager.dbManagerMSSQL.leer_archivo_de_propiedades();
            }
        }
    }

    // Método para obtener la conexión
    public Connection getConnection() {
        try {
            Class.forName(this.driver);
            // Descifra la contraseña al momento de crear la conexión
            this.conexion = DriverManager.getConnection(getURL(), this.usuario, Cifrado.descifrarMD5(this.contraseña));
        } catch (ClassNotFoundException | SQLException ex) {
            System.err.println("Error al generar la conexión - " + ex);
        }
        return conexion;
    }

    // --- Métodos Abstractos (Contrato para las clases hijas) ---
    
    protected abstract String getURL();

    protected abstract void leer_archivo_de_propiedades();
    
    public abstract String retornarSQLParaUltimoAutoGenerado();
    
    // Métodos abstractos de tu diseño original (importante agregarlos)
    public abstract String retornarSQLParaDateTime(String columnaFecha, String columnaHora);

    public abstract String retornarFechaActual();
}
