/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transitsoft.db;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

/**
 *
 * @author USUARIO
 */
public class DBManagerMySQL extends DBManager {

    protected DBManagerMySQL(){
        // Constructor protegido (Singleton)
    }

    @Override
    protected String getURL() {
        String url = this.tipo_de_driver.concat("://");
        url = url.concat(this.nombre_de_host);
        url = url.concat(":");
        url = url.concat(this.puerto);
        url = url.concat("/");
        url = url.concat(this.base_de_datos);
        url = url.concat("?useSSL=false");
        return url;
    }
    
    @Override
    public String retornarSQLParaUltimoAutoGenerado(){
        // (Usando la sintaxis de tu implementación original)
        return "select @@last_insert_id as id";
    }

    @Override
    protected void leer_archivo_de_propiedades() {
        Properties properties = new Properties();
        try {
            String nmArchivoConf = "/" + ARCHIVO_CONFIGURACION;

            properties.load(this.getClass().getResourceAsStream(nmArchivoConf));
            // Lee las propiedades específicas de MySQL
            this.driver = properties.getProperty("driver_mysql");
            this.tipo_de_driver = properties.getProperty("tipo_de_driver_mysql");
            this.base_de_datos = properties.getProperty("base_de_datos_mysql");
            this.nombre_de_host = properties.getProperty("nombre_de_host_mysql");
            this.puerto = properties.getProperty("puerto_mysql");
            this.usuario = properties.getProperty("usuario_mysql");
            this.contraseña = properties.getProperty("contrasenha");
        } catch (FileNotFoundException ex) {
            System.err.println("Error al leer el archivo de propiedades - " + ex);
        } catch (IOException ex) {
            System.err.println("Error al leer el archivo de propiedades - " + ex);
        }
    }
    
    // --- Implementación de los métodos de contrato ---
    
    @Override
    public String retornarSQLParaDateTime(String columnaFecha, String columnaHora) {
        // (Sintaxis de tu implementación original de MySQL)
        return "TIMESTAMP("+columnaFecha+", "+columnaHora+")";
    }

    @Override
    public String retornarFechaActual() {
        // (Sintaxis de tu implementación original de MySQL)
        return "NOW()";
    }

}
