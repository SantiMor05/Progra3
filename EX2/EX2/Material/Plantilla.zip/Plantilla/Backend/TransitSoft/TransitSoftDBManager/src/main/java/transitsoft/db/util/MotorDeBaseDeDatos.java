package transitsoft.db.util;

public enum MotorDeBaseDeDatos {
    MYSQL, MSSQL
}