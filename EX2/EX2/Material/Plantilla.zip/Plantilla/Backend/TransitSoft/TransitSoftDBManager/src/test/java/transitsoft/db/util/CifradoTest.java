/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package transitsoft.db.util;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Lenovo
 */
public class CifradoTest {
    
    public CifradoTest() {
    }

    /**
     * Test of cifrarMD5 method, of class Cifrado.
     */
    @Test
    public void testCifrarMD5() {
        System.out.println("cifrarMD5");
        String texto = "benchelelaboratorio14";
        String expResult = "";
        String result = Cifrado.cifrarMD5(texto);
        System.out.println("Resultado: " + result);

    }

    /**
     * Test of descifrarMD5 method, of class Cifrado.
     */
    @Test
    public void testDescifrarMD5() {
        System.out.println("descifrarMD5");
        String textoEncriptado = "jiEGpOZaB9KpuqauYJB30YjnkzSZE4v8";
        String expResult = "";
        String result = Cifrado.descifrarMD5(textoEncriptado);
        System.out.println("Resultado: " + result);
    }
    
}
