/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transitsoft.db;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

/**
 *
 * @author USUARIO
 */
public class DBManagerMSSQL extends DBManager {

    protected DBManagerMSSQL() {
        // Constructor protegido (Singleton)
    }

    @Override
    protected String getURL() {
        String url = this.tipo_de_driver.concat("://");
        url = url.concat(this.nombre_de_host);
        url = url.concat(":");
        url = url.concat(this.puerto);
        url = url.concat(";");
        url = url.concat("databaseName=" + this.base_de_datos);
        url = url.concat(";encrypt=false");
        return url;
    }
    
    @Override
    public String retornarSQLParaUltimoAutoGenerado(){
        // (Usando la sintaxis de tu implementación original)
        return "select @@IDENTITY as id";
    }
    
    @Override
    protected void leer_archivo_de_propiedades() {
        Properties properties = new Properties();
        try {
            String nmArchivoConf = "/" + ARCHIVO_CONFIGURACION;

            properties.load(this.getClass().getResourceAsStream(nmArchivoConf));
            // Lee las propiedades genéricas (sin sufijo) para MSSQL
            this.driver = properties.getProperty("driver");
            this.tipo_de_driver = properties.getProperty("tipo_de_driver");
            this.base_de_datos = properties.getProperty("base_de_datos");
            this.nombre_de_host = properties.getProperty("nombre_de_host");
            this.puerto = properties.getProperty("puerto");
            this.usuario = properties.getProperty("usuario");
            this.contraseña = properties.getProperty("contrasenha");
        } catch (FileNotFoundException ex) {
            System.err.println("Error al leer el archivo de propiedades - " + ex);
        } catch (IOException ex) {
            System.err.println("Error al leer el archivo de propiedades - " + ex);
        }
    }
    
    // --- Implementación de los métodos de contrato ---

    @Override
    public String retornarSQLParaDateTime(String columnaFecha, String columnaHora) {
        // (Sintaxis de tu implementación original de MSSQL)
        return "CAST(" + columnaFecha + " AS DATETIME) + CAST(" + columnaHora + " AS DATETIME)";
    }

    @Override
    public String retornarFechaActual() {
        // (Sintaxis de tu implementación original de MSSQL)
        return "GETDATE()";
    }
}
