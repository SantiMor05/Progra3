/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transitsoft.daoImp;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.function.Consumer;
import transitsoft.dao.CapturaDAO;
import transitsoft.daoImp.util.Columna;
import transitsoft.model.CamaraDTO;
import transitsoft.model.CapturaDTO;
import transitsoft.model.EstadoCaptura;
import transitsoft.model.PropietarioDTO;
import transitsoft.model.VehiculoDTO;

/**
 *
 * @author USUARIO
 */
public class CapturaDAOImp extends DAOImplBase implements CapturaDAO {

    private CapturaDTO captura;
    private Boolean esProcedure;
    public CapturaDAOImp() {
        super("captura", "MYSQL");
        retornarLlavePrimaria = true;
        captura = null;
        esProcedure = false;
    }

    @Override
    public Integer insertar(CapturaDTO captura) {
        this.captura = captura;
        retornarLlavePrimaria = true;
        return super.insertar();
    }

    @Override
    public List<CapturaDTO> leerTodos() {
//        String sql = "{call listarCapturas()}";
//        boolean ConTransaccion = false;
//        return (List<CapturaDTO>) super.ejecutarProcedimientoAlmacenadoSELECT(sql, ConTransaccion);

        //En las 2 bases de datos
        // Asumimos que el Stored Procedure se llama igual en AMBAS bases de datos
        String sp_mysql = "{call listarCapturas()}";
        //String sp_mssql = "{call listarCapturas()}";
        String sp_mssql = null;
        esProcedure = true;
        return (List<CapturaDTO>) super.listarTodos(sp_mysql, null, null);
        // 2. LLAMAS AL MÉTODO FEDERADO
        // Esto consultará MySQL, luego MSSQL, y combinará los resultados
        //return (List<CapturaDTO>) super.listarTodosFederado(sp_mysql, sp_mssql);
    }

    @Override
    public Integer actualizar(CapturaDTO captura) {
        this.captura = captura;
        return super.modificar();
    }

    @Override
    protected void configurarListaDeColumnas() {
        this.listaColumnas.add(new Columna("id", true, true));
        this.listaColumnas.add(new Columna("id_camara", false, false));
        this.listaColumnas.add(new Columna("placa", false, false));
        this.listaColumnas.add(new Columna("velocidad", false, false));
        this.listaColumnas.add(new Columna("fecha_captura", false, false));
        this.listaColumnas.add(new Columna("estado", false, false));
    }

    @Override
    protected void incluirValorDeParametrosParaModificacion() throws SQLException {
        statement.setInt(1, captura.getCamara().getId());
        statement.setString(2, captura.getPlaca());
        statement.setDouble(3, captura.getVelocidad());
        Date fechaUtil = captura.getFechaCaptura();
        java.sql.Date fechaSQL = new java.sql.Date(fechaUtil.getTime());
        statement.setDate(4, fechaSQL);
        String estado;
        if (captura.getEstado() == EstadoCaptura.PROCESADO) {
            estado = "PROCESADO";
        } else {
            estado = "REGISTRADO";
        }
        statement.setString(5, estado);
        statement.setInt(6, captura.getId());
    }

    @Override
    protected void instanciarObjetoDelResultSet() throws SQLException {
        this.captura = new CapturaDTO();
        this.captura.setId(this.resultSet.getInt("id"));
        CamaraDTO camara = new CamaraDTO();
        camara.setId(resultSet.getInt("id_camara"));
        if(esProcedure){
            camara.setModelo(resultSet.getString("camara_modelo"));
            camara.setCodigoSerie(resultSet.getString("camara_codigo_serie"));
            camara.setLatitud(resultSet.getInt("camara_latitud"));
            camara.setLongitud(resultSet.getInt("camara_longitud")); 
            
            //Datos propietario
            PropietarioDTO pro = new PropietarioDTO();
            pro.setId(resultSet.getInt("id_propietario"));
            pro.setDni(resultSet.getString("propietario_dni"));
            pro.setNombres(resultSet.getString("propietario_nombres"));
            pro.setApellidos(resultSet.getString("propietario_apellidos"));
            pro.setDireccion(resultSet.getString("propietario_direccion"));
            VehiculoDTO vehiculo = new VehiculoDTO();
            vehiculo.setId(resultSet.getInt("id_vehiculo"));
            vehiculo.setPlaca(resultSet.getString("vehiculo_placa"));
            vehiculo.setPropietario(pro);
            vehiculo.setMarca(resultSet.getString("vehiculo_marca"));
            vehiculo.setModelo(resultSet.getString("vehiculo_modelo"));
            vehiculo.setAnho(resultSet.getInt("vehiculo_anho"));
            captura.setVehiculo(vehiculo); 
        }
        this.captura.setCamara(camara);
        this.captura.setPlaca(this.resultSet.getString("placa"));
        captura.setVelocidad(resultSet.getDouble("velocidad"));
        captura.setFechaCaptura(new java.util.Date(resultSet.getDate("fecha_captura").getTime()));
        if ("REGISTRADO".equals(resultSet.getString("estado"))) {
            captura.setEstado(EstadoCaptura.REGISTRADO);
        } else {
            captura.setEstado(EstadoCaptura.PROCESADO);
        }        
    }

    @Override
    protected void limpiarObjetoDelResultSet() {
        this.captura = null;
    }

    @Override
    protected void agregarObjetoALaLista(List lista) throws SQLException {
        this.instanciarObjetoDelResultSet();
        lista.add(this.captura);
    }

    @Override
    public Integer eliminar(CapturaDTO captura) {
        this.captura = captura;
        return super.eliminar();
    }

    @Override
    public ArrayList<CapturaDTO> listarTodos() {
        return (ArrayList<CapturaDTO>) super.listarTodos();
    }

    @Override
    public Integer modificar(CapturaDTO captura) {
        this.captura = captura;
        esProcedure = false;
        return super.modificar();
    }

    @Override
    public CapturaDTO obtenerPorId(Integer capturaId) {
        CapturaDTO captura = new CapturaDTO();
        captura.setId(capturaId);
        this.captura = captura;
        super.obtenerPorId();
        return this.captura;
    }

    @Override
    protected void incluirValorDeParametrosParaEliminacion() throws SQLException {
        this.statement.setInt(1, this.captura.getId());
    }

    @Override
    protected void incluirValorDeParametrosParaInsercion() throws SQLException {
        this.statement.setInt(1, this.captura.getCamara().getId());
        this.statement.setString(2, this.captura.getPlaca());
        this.statement.setDouble(3, this.captura.getVelocidad());
        java.util.Date fechaUtil = captura.getFechaCaptura();
        java.sql.Date fechaSQL = new java.sql.Date(fechaUtil.getTime());
        this.statement.setDate(4, fechaSQL);
        String estado;
        if (captura.getEstado() == EstadoCaptura.PROCESADO) {
            estado = "PROCESADO";
        } else {
            estado = "REGISTRADO";
        }
        statement.setString(5, estado);
    }
    
    //Ejemplo implementacion
    public void COnParametrosDeSalida(Integer id, CamaraDTO camara, String placa, Double velocidad, Date fechaCaptura, EstadoCaptura estado, VehiculoDTO vehiculo) {
        Object parametros = new CapturaDTO(id, camara, placa, velocidad, fechaCaptura, estado, vehiculo);

        String sql = "{call SP_VALIDAR_STOCK(?, ?, ?, ?, ?)}";
        Boolean conTransaccion = false;

        this.ejecutarProcedimientoAlmacenadoConOUT(
            sql, 
            this::incluirValorDeParametrosParaValidarStock, 
            parametros,
            this::procesarParametrosOUTParaValidarStock,
            conTransaccion
        );

        // Usar los resultados
        CapturaDTO params = (CapturaDTO) parametros;
        System.out.println("Almacen ID: " + params.getId());
        System.out.println("Nombre: " + params.getPlaca());
        //System.out.println("Almacen central: " + params.getBoolean());
    }

    private void incluirValorDeParametrosParaValidarStock(Object objetoParametros) {
        CapturaDTO parametros = (CapturaDTO) objetoParametros;
        try {
            // Parámetros IN
            this.statement.setInt(1, parametros.getId());
            this.statement.setString(2, parametros.getPlaca());

            // Registrar parámetros OUT
            this.statement.registerOutParameter(3, java.sql.Types.INTEGER);  // stock_disponible
            this.statement.registerOutParameter(4, java.sql.Types.BOOLEAN);  // es_valido
            this.statement.registerOutParameter(5, java.sql.Types.VARCHAR);  // mensaje
        } catch (SQLException ex) {
            System.getLogger(CapturaDAOImp.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }
    }

    private void procesarParametrosOUTParaValidarStock(Object objetoParametros) {
        CapturaDTO parametros = (CapturaDTO) objetoParametros;
        try {
            parametros.setId(this.statement.getInt(3));
            //parametros.setBoolean(this.statement.getBoolean(4));
            parametros.setPlaca(this.statement.getString(5));
        } catch (SQLException ex) {
            System.getLogger(CapturaDAOImp.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }
    }

    @Override
    protected void incluirValorDeParametrosParaObtenerPorId() throws SQLException {
        // El SQL que se genera es: SELECT ... FROM captura WHERE id=?
        // Debemos setear el primer parámetro (el 'id')
        
        // 'this.captura' ya fue seteado con el ID en el método obtenerPorId(Integer capturaId)
        this.statement.setInt(1, this.captura.getId());
    }
    
    
    
    
    // --- Ejemplo de un NUEVO método federado CON PARÁMETROS ---
    
    /**
     * Busca capturas por placa en AMBAS bases de datos.
     * (Este es un método nuevo, solo como ejemplo)
     */
    public List<CapturaDTO> listarPorPlacaFederado(String placa) {
        
        String sp_mysql = "{call sp_listarCapturas_por_placa(?)}";
        String sp_mssql = "{call sp_listarCapturas_por_placa(?)}";
        
        // Usamos un objeto simple (String) para pasar el parámetro
        Object parametros = placa; 
        
        // 3. LLAMAS A LA SOBRECARGA FEDERADA CON PARÁMETROS
        return (List<CapturaDTO>) super.listarTodosFederado(
            sp_mysql, this::incluirParametrosListarPlaca, parametros, // Para MySQL
            sp_mssql, this::incluirParametrosListarPlaca, parametros  // Para MSSQL
        );
    }
    
    /**
     * Método helper (reutilizable) para setear los parámetros 
     * del procedure 'sp_listarCapturas_por_placa'.
     * @param objetoParametros En este caso, es un String (la placa)
     */
    private void incluirParametrosListarPlaca(Object objetoParametros) {
        try {
            String placa = (String) objetoParametros;
            // this.statement es asignado por la clase base (DAOImplBase)
            // antes de llamar a este método.
            this.statement.setString(1, placa);
        } catch (SQLException ex) {
            System.err.println("Error al setear parámetros de placa: " + ex);
        }
    }
}
