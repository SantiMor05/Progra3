package transitsoft.daoImp; // O el paquete que estés usando

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import transitsoft.daoImp.util.Columna;
import transitsoft.daoImp.util.Tipo_Operacion;
import transitsoft.db.DBManager; // Asegúrate que importe tu nuevo DBManager

/**
 *
 * @author USUARIO
 */
public abstract class DAOImplBase {
    protected String nombre_tabla;
    protected ArrayList<Columna> listaColumnas;
    protected Boolean retornarLlavePrimaria;
    protected Connection conexion;
    protected CallableStatement statement;
    protected ResultSet resultSet;
    
    // --- NUEVO CAMPO ---
    // Define el motor ("MYSQL" o "MSSQL") para operaciones de escritura (INSERT, UPDATE, DELETE)
    // y lecturas de un solo objeto (obtenerPorId)
    protected String motorPrincipal;

    // --- CONSTRUCTOR MODIFICADO ---
    public DAOImplBase(String nombre_tabla, String motorPrincipal) {
        this.nombre_tabla = nombre_tabla;
        this.motorPrincipal = motorPrincipal; // Se asigna el motor principal
        this.retornarLlavePrimaria = false;
        this.incluirListaDeColumnas();
    }

    private void incluirListaDeColumnas() {
        this.listaColumnas = new ArrayList<>();
        this.configurarListaDeColumnas();
    }
    
    protected abstract void configurarListaDeColumnas();
    
    //Para la BD
    protected void abrirConexion() {
        try {
            // --- MODIFICADO ---
            // Se conecta usando el motor principal definido en el constructor
            this.conexion = DBManager.getInstance(this.motorPrincipal).getConnection();
            // --- FIN MODIFICACIÓN ---
        } catch (Exception ex) {
            System.err.println("Error al abrir la conexión con el motor principal: " + this.motorPrincipal + " - " + ex);
        }
    }
    
    protected void cerrarConexion() throws SQLException {
        if (this.conexion != null) {
            this.conexion.close();
            this.conexion = null; // Buena práctica
        }
    }
    
    protected void iniciarTransaccion() throws SQLException {
        this.abrirConexion();
        this.conexion.setAutoCommit(false);
    }
    
    protected void comitarTransaccion() throws SQLException {
        this.conexion.commit();
    }
    
    protected void rollbackTransaccion() throws SQLException {
        if (this.conexion != null) {
            this.conexion.rollback();
        }
    }
    
    protected void colocarSQLEnStatement(String sql) throws SQLException {
        System.out.println(sql);
        this.statement = this.conexion.prepareCall(sql);
    }
    
    protected Integer ejecutarDMLEnBD() throws SQLException {
        return this.statement.executeUpdate();
    }

    protected void ejecutarSelectEnDB() throws SQLException {
        this.resultSet = this.statement.executeQuery();
    }
    
    //Eleccion de operacion (Sin cambios, usarán el motorPrincipal)
    
    protected Integer insertar() {
        return this.ejecuta_DML(Tipo_Operacion.INSERTAR);
    }

    protected Integer modificar() {
        return this.ejecuta_DML(Tipo_Operacion.MODIFICAR);
    }

    protected Integer eliminar() {
        return this.ejecuta_DML(Tipo_Operacion.ELIMINAR);
    }
    
    private Integer ejecuta_DML(Tipo_Operacion tipo_operacion) {
        Integer resultado = 0;
        try {
            this.iniciarTransaccion(); // Usa el motorPrincipal
            String sql = null;
            switch (tipo_operacion) {
                case Tipo_Operacion.INSERTAR:
                    sql = this.generarSQLParaInsercion();
                    break;
                case Tipo_Operacion.MODIFICAR:
                    sql = this.generarSQLParaModificacion();
                    break;
                case Tipo_Operacion.ELIMINAR:
                    sql = this.generarSQLParaEliminacion();
                    break;
            }
            this.colocarSQLEnStatement(sql);
            switch (tipo_operacion) {
                case Tipo_Operacion.INSERTAR:
                    this.incluirValorDeParametrosParaInsercion();
                    break;
                case Tipo_Operacion.MODIFICAR:
                    this.incluirValorDeParametrosParaModificacion();
                    break;
                case Tipo_Operacion.ELIMINAR:
                    this.incluirValorDeParametrosParaEliminacion();
                    break;
            }
            resultado = this.ejecutarDMLEnBD();
            if (this.retornarLlavePrimaria && tipo_operacion == Tipo_Operacion.INSERTAR) {
                resultado = this.retornarUltimoAutoGenerado(); // Usa el motorPrincipal
            }
            this.comitarTransaccion();
        } catch (SQLException ex) {
            System.err.println("Error al intentar insertar - " + ex);
            try {
                this.rollbackTransaccion();
            } catch (SQLException ex1) {
                System.err.println("Error al hacer rollback - " + ex1);
            }
        } finally {
            try {
                this.cerrarConexion();
            } catch (SQLException ex) {
                System.err.println("Error al cerrar la conexión - " + ex);
            }
        }
        return resultado;
    }
    
    //SQL's (Sin cambios)
    
    protected String generarSQLParaInsercion() {
        // ... (código original sin cambios)
        String sql = "INSERT INTO ";
        sql = sql.concat(this.nombre_tabla);
        sql = sql.concat("(");
        String sql_columnas = "";
        String sql_parametros = "";
        for (Columna columna : this.listaColumnas) {
            if (!columna.getEsAutoGenerado()) {
                if (!sql_columnas.isBlank()) {
                    sql_columnas = sql_columnas.concat(", ");
                    sql_parametros = sql_parametros.concat(", ");
                }
                sql_columnas = sql_columnas.concat(columna.getNombre());
                sql_parametros = sql_parametros.concat("?");
            }
        }
        sql = sql.concat(sql_columnas);
        sql = sql.concat(") VALUES (");
        sql = sql.concat(sql_parametros);
        sql = sql.concat(")");
        return sql;
    }

    protected String generarSQLParaModificacion() {
        // ... (código original sin cambios)
        String sql = "UPDATE ";
        sql = sql.concat(this.nombre_tabla);
        sql = sql.concat(" SET ");
        String sql_columnas = "";
        String sql_predicado = "";
        for (Columna columna : this.listaColumnas) {
            if (columna.getEsLlavePrimaria()) {
                if (!sql_predicado.isBlank()) {
                    //no está probado
                    sql_predicado = sql_predicado.concat(" AND ");
                }
                sql_predicado = sql_predicado.concat(columna.getNombre());
                sql_predicado = sql_predicado.concat("=?");
            } else {
                if (!sql_columnas.isBlank()) {
                    sql_columnas = sql_columnas.concat(", ");
                }
                sql_columnas = sql_columnas.concat(columna.getNombre());
                sql_columnas = sql_columnas.concat("=?");
            }
        }
        sql = sql.concat(sql_columnas);
        sql = sql.concat(" WHERE ");
        sql = sql.concat(sql_predicado);
        return sql;
    }

    protected String generarSQLParaEliminacion() {
        // ... (código original sin cambios)
        String sql = "DELETE FROM ";
        sql = sql.concat(this.nombre_tabla);
        sql = sql.concat(" WHERE ");
        String sql_predicado = "";
        for (Columna columna : this.listaColumnas) {
            if (columna.getEsLlavePrimaria()) {
                if (!sql_predicado.isBlank()) {
                    sql_predicado = sql_predicado.concat(", ");
                }
                sql_predicado = sql_predicado.concat(columna.getNombre());
                sql_predicado = sql_predicado.concat("=?");
            }
        }
        sql = sql.concat(sql_predicado);
        return sql;
    }

    protected String generarSQLParaObtenerPorId() {
        // ... (código original sin cambios)
        String sql = "SELECT ";
        String sql_columnas = "";
        String sql_predicado = "";
        for (Columna columna : this.listaColumnas) {
            if (columna.getEsLlavePrimaria()) {
                if (!sql_predicado.isBlank()) {
                    sql_predicado = sql_predicado.concat(", ");
                }
                sql_predicado = sql_predicado.concat(columna.getNombre());
                sql_predicado = sql_predicado.concat("=?");
            }
            if (!sql_columnas.isBlank()) {
                sql_columnas = sql_columnas.concat(", ");
            }
            sql_columnas = sql_columnas.concat(columna.getNombre());
        }
        sql = sql.concat(sql_columnas);
        sql = sql.concat(" FROM ");
        sql = sql.concat(this.nombre_tabla);
        sql = sql.concat(" WHERE ");
        sql = sql.concat(sql_predicado);
        return sql;
    }

    protected String generarSQLParaListarTodos() {
        // ... (código original sin cambios)
        String sql = "SELECT ";
        String sql_columnas = "";
        for (Columna columna : this.listaColumnas) {
            if (!sql_columnas.isBlank()) {
                sql_columnas = sql_columnas.concat(", ");
            }
            sql_columnas = sql_columnas.concat(columna.getNombre());
        }
        sql = sql.concat(sql_columnas);
        sql = sql.concat(" FROM ");
        sql = sql.concat(this.nombre_tabla);
        return sql;
    }
    
    // Métodos abstractos (Sin cambios)
    protected void incluirValorDeParametrosParaInsercion() throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    protected void incluirValorDeParametrosParaModificacion() throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    protected void incluirValorDeParametrosParaEliminacion() throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    public Integer retornarUltimoAutoGenerado() {
        Integer resultado = null;
        try {
            // --- MODIFICADO ---
            // Obtiene el SQL específico del motor principal que está usando la conexión
            String sql = DBManager.getInstance(this.motorPrincipal).retornarSQLParaUltimoAutoGenerado();
            // --- FIN MODIFICACIÓN ---
            
            this.statement = this.conexion.prepareCall(sql);
            this.resultSet = this.statement.executeQuery();
            if (this.resultSet.next()) {
                resultado = this.resultSet.getInt("id");
            }
        } catch (SQLException ex) {
            System.err.println("Error al intentar retornarUltimoAutoGenerado - " + ex);
        }
        return resultado;
    }
    
    // Método para obtener UN objeto (Sin cambios, usará el motorPrincipal)
    public void obtenerPorId() {
        try {
            this.abrirConexion(); // Usa el motorPrincipal
            String sql = this.generarSQLParaObtenerPorId();
            this.colocarSQLEnStatement(sql);
            this.incluirValorDeParametrosParaObtenerPorId();
            this.ejecutarSelectEnDB();
            if (this.resultSet.next()) {
                this.instanciarObjetoDelResultSet();
            } else {
                this.limpiarObjetoDelResultSet();
            }
        } catch (SQLException ex) {
            System.err.println("Error al intentar obtenerPorId - " + ex);
        } finally {
            try {
                this.cerrarConexion();
            } catch (SQLException ex) {
                System.err.println("Error al cerrar la conexión - " + ex);
            }
        }
    }
    
    // Métodos abstractos (Sin cambios)
    protected void incluirValorDeParametrosParaObtenerPorId() throws SQLException {
        throw new UnsupportedOperationException("El método no ha sido sobreescrito."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    protected void instanciarObjetoDelResultSet() throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    protected void limpiarObjetoDelResultSet() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    //Listar con o sin procedure (Sin cambios, usará el motorPrincipal)
    public List listarTodos() {
        String sql = null;
        Consumer incluirValorDeParametros = null;
        Object parametros = null;
        return this.listarTodos(sql, incluirValorDeParametros, parametros);
    }

    public List listarTodos(String sql,
                            Consumer incluirValorDeParametros,
                            Object parametros) {
        List lista = new ArrayList<>();
        try {
            this.abrirConexion(); // Usa el motorPrincipal
            if (sql == null) {
                sql = this.generarSQLParaListarTodos();
            }
            this.colocarSQLEnStatement(sql);
            if (incluirValorDeParametros != null) {
                incluirValorDeParametros.accept(parametros);
            }
            this.ejecutarSelectEnDB();
            while (this.resultSet.next()) {
                agregarObjetoALaLista(lista);
            }
        } catch (SQLException ex) {
            System.err.println("Error al intentar listarTodos - " + ex);
        } finally {
            try {
                this.cerrarConexion();
            } catch (SQLException ex) {
                System.err.println("Error al cerrar la conexión - " + ex);
            }
        }
        return lista;
    }

    // Método abstracto (Sin cambios)
    protected void agregarObjetoALaLista(List lista) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    //Procedures (Sin cambios, usarán el motorPrincipal)
    
    //Procedures DML
    public void ejecutarProcedimientoAlmacenado(String sql,
            Boolean conTransaccion) {
        // ... (código original sin cambios)
        Consumer incluirValorDeParametros = null;
        Object parametros = null;
        this.ejecutarProcedimientoAlmacenado(sql, incluirValorDeParametros, parametros, conTransaccion);
    }

    public void ejecutarProcedimientoAlmacenado(String sql,
            Consumer incluirValorDeParametros,
            Object parametros,
            Boolean conTransaccion) {
        // ... (código original sin cambios)
        try {
            if (conTransaccion) {
                this.iniciarTransaccion();
            } else {
                this.abrirConexion();
            }
            this.colocarSQLEnStatement(sql);
            if (incluirValorDeParametros != null) {
                incluirValorDeParametros.accept(parametros);
            }
            this.ejecutarDMLEnBD();
            if (conTransaccion) {
                this.comitarTransaccion();
            }
        } catch (SQLException ex) {
            System.err.println("Error al intentar ejecutar procedimiento almacenado: " + ex);
            try {
                if (conTransaccion) {
                    this.rollbackTransaccion();
                }
            } catch (SQLException ex1) {
                System.err.println("Error al hacer rollback - " + ex);
            }
        } finally {
            try {
                this.cerrarConexion();
            } catch (SQLException ex) {
                System.err.println("Error al cerrar la conexión - " + ex);
            }
        }
    }
    
    //Procedures SELECT
    public List ejecutarProcedimientoAlmacenadoSELECT(String sql,
            Boolean conTransaccion) {
        // ... (código original sin cambios)
        Consumer incluirValorDeParametros = null;
        Object parametros = null;
        return this.ejecutarProcedimientoAlmacenadoSELECT(sql, incluirValorDeParametros, parametros, conTransaccion);
    }

    public List ejecutarProcedimientoAlmacenadoSELECT(String sql,
            Consumer incluirValorDeParametros,
            Object parametros,
            Boolean conTransaccion) {
        // ... (código original sin cambios)
        List lista = new ArrayList<>();
        try {
            this.abrirConexion();
            this.colocarSQLEnStatement(sql);
            if (incluirValorDeParametros != null) {
                incluirValorDeParametros.accept(parametros);
            }
            this.ejecutarSelectEnDB();
            while (this.resultSet.next()) {
                agregarObjetoALaLista(lista);
            }
        } catch (SQLException ex) {
            System.err.println("Error al intentar ejecutar procedimiento almacenado: " + ex);
            try {
                if (conTransaccion) {
                    this.rollbackTransaccion();
                }
            } catch (SQLException ex1) {
                System.err.println("Error al hacer rollback - " + ex);
            }
        } finally {
            try {
                this.cerrarConexion();
            } catch (SQLException ex) {
                System.err.println("Error al cerrar la conexión - " + ex);
            }
        }
        return lista;
    }
    
    //Procedures con parametros de salida
    // Procedures DML con parámetros OUT
    public void ejecutarProcedimientoAlmacenadoConOUT(
            String sql,
            Consumer incluirValorDeParametros,
            Object parametros,
            Consumer procesarParametrosOUT,
            Boolean conTransaccion) {
        // ... (código original sin cambios)
        try {
            if (conTransaccion) {
                this.iniciarTransaccion();
            } else {
                this.abrirConexion();
            }
            this.colocarSQLEnStatement(sql);

            // Configurar parámetros IN y registrar OUT
            if (incluirValorDeParametros != null) {
                incluirValorDeParametros.accept(parametros);
            }

            // Ejecutar procedure (cambiado de executeUpdate a execute para OUT)
            this.statement.execute();

            // Procesar parámetros OUT
            if (procesarParametrosOUT != null) {
                procesarParametrosOUT.accept(parametros);
            }

            if (conTransaccion) {
                this.comitarTransaccion();
            }
        } catch (SQLException ex) {
            System.err.println("Error al intentar ejecutar procedimiento almacenado con OUT: " + ex);
            try {
                if (conTransaccion) {
                    this.rollbackTransaccion();
                }
            } catch (SQLException ex1) {
                System.err.println("Error al hacer rollback - " + ex1);
            }
        } finally {
            try {
                this.cerrarConexion();
            } catch (SQLException ex) {
                System.err.println("Error al cerrar la conexión - " + ex);
            }
        }
    }

    // Sobrecarga sin parámetros
    public void ejecutarProcedimientoAlmacenadoConOUT(
            String sql,
            Boolean conTransaccion) {
        // ... (código original sin cambios)
        Consumer incluirValorDeParametros = null;
        Object parametros = null;
        Consumer procesarParametrosOUT = null;
        this.ejecutarProcedimientoAlmacenadoConOUT(sql, incluirValorDeParametros, parametros, procesarParametrosOUT, conTransaccion);
    }
    
    
    // =========================================================================
    // =========== MÉTODOS NUEVOS PARA CONSULTAS FEDERADAS (DUAL-DB) ===========
    // =========================================================================

    public List listarTodosFederado(String sqlMySQL, String sqlMSSQL) {
        // Llama a la sobrecarga más compleja sin parámetros
        return this.listarTodosFederado(sqlMySQL, null, null, sqlMSSQL, null, null);
    }


    public List listarTodosFederado(String sqlMySQL,
                                    Consumer incluirValorDeParametrosMySQL,
                                    Object parametrosMySQL,
                                    String sqlMSSQL,
                                    Consumer incluirValorDeParametrosMSSQL,
                                    Object parametrosMSSQL) {
                                        
        List listaTotal = new ArrayList<>();
        
        // --- 1. CONSULTA A MYSQL ---
        // Se usa try-with-resources para asegurar que la conexión y el statement
        // de MySQL se cierren automáticamente, incluso si hay un error.
        try (Connection connMySQL = DBManager.getInstance("MYSQL").getConnection();
             CallableStatement stmtMySQL = connMySQL.prepareCall(sqlMySQL)) {
            
            if (incluirValorDeParametrosMySQL != null) {
                // Truco: Asignamos el statement local (stmtMySQL) al 'statement' de la clase
                // para que el Consumer (definido en la clase hija) pueda operar sobre él.
                this.statement = stmtMySQL;
                incluirValorDeParametrosMySQL.accept(parametrosMySQL);
            }
            
            System.out.println("Ejecutando en MySQL (Federado): " + sqlMySQL);
            ResultSet rsMySQL = stmtMySQL.executeQuery();
            
            while (rsMySQL.next()) {
                // Truco: Asignamos el ResultSet local (rsMySQL) al 'resultSet' de la clase
                // para que 'agregarObjetoALaLista' (definido en la hija) pueda leerlo.
                this.resultSet = rsMySQL; 
                agregarObjetoALaLista(listaTotal);
            }
            
            rsMySQL.close();
            
        } catch (SQLException ex) {
            System.err.println("Error al consultar MySQL (Federado con params) - " + ex);
            // Se decide continuar con MSSQL aunque MySQL haya fallado.
        }

        // --- 2. CONSULTA A MSSQL ---
        try (Connection connMSSQL = DBManager.getInstance("MSSQL").getConnection();
             CallableStatement stmtMSSQL = connMSSQL.prepareCall(sqlMSSQL)) {
            
            if (incluirValorDeParametrosMSSQL != null) {
                // Re-asignamos el statement de la clase al statement local de MSSQL
                this.statement = stmtMSSQL;
                incluirValorDeParametrosMSSQL.accept(parametrosMSSQL);
            }
            
            System.out.println("Ejecutando en MSSQL (Federado): " + sqlMSSQL);
            ResultSet rsMSSQL = stmtMSSQL.executeQuery();

            while (rsMSSQL.next()) {
                // Re-asignamos el resultSet de la clase al resultSet local de MSSQL
                this.resultSet = rsMSSQL;
                agregarObjetoALaLista(listaTotal);
            }
            
            rsMSSQL.close();

        } catch (SQLException ex) {
            System.err.println("Error al consultar MSSQL (Federado con params) - " + ex);
        }
        
        // Limpiamos las variables de clase para evitar fugas de memoria o estados inválidos
        this.resultSet = null;
        this.statement = null; 
        
        return listaTotal;
    }
}