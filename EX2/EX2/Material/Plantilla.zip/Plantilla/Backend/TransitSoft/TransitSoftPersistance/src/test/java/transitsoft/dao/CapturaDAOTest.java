/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package transitsoft.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import transitsoft.daoImp.CapturaDAOImp;
import transitsoft.model.CamaraDTO;
import transitsoft.model.CapturaDTO;

/**
 *
 * @author Lenovo
 */
public class CapturaDAOTest {
    
    private CapturaDAO capturaDAO;
    
    public CapturaDAOTest() {
        // Esto ahora llama al constructor actualizado de CapturaDAOImp
        this.capturaDAO = new CapturaDAOImp();
    }
    
    @Test
    public void testObtenerPorId() {
        System.out.println("Obtener por id");
        CapturaDTO captura = capturaDAO.obtenerPorId(1);
        
        System.out.println(captura);
    }
    @Test
    public void testModificar() {
        System.out.println("Modificar");
        CapturaDTO captura = new CapturaDTO();
        captura.setId(27);
        captura.setPlaca("!!!222");
        CamaraDTO camara = new CamaraDTO();
        camara.setId(2);
        captura.setVelocidad(Double.valueOf(50));
        captura.setCamara(camara);
        
        Date fecha = new Date();
        captura.setFechaCaptura(fecha);
        int resultado = capturaDAO.modificar(captura);
        
        System.out.println(captura);
        System.out.println("Resultado: " + resultado);
    }
    
    

    
    
////     ===============================================
////     ===========  NUEVO TEST AÑADIDO  ==============
////     ===============================================
//
//    /**
//     * Prueba que el método leerTodos() llame correctamente al
//     * Stored Procedure "listarCapturas" en la base de datos principal.
//     */
//    @Test
//    public void testListarTodosConProcedure() {
//        System.out.println("listarTodos (usando Stored Procedure en 1 BD)");
//        
//        // 1. EJECUCIÓN
//        // Este método usa 'ejecutarProcedimientoAlmacenadoSELECT' 
//        // sobre el 'motorPrincipal'
//        List<CapturaDTO> lista = this.capturaDAO.leerTodos();
//        
//        // 2. VERIFICACIÓN (Assertions)
//        
//        // Verificamos que la lista no sea nula
//        assertNotNull(lista, "La lista de capturas no debe ser nula.");
//        
//        // Verificamos que la lista contenga elementos
//        // (Esto asume que tu BD de prueba NO está vacía)
//        assertFalse(lista.isEmpty(), "La lista no debe estar vacía. Asegúrate de tener datos en la BD.");
//        
//        // 3. VERIFICACIÓN VISUAL (Opcional)
//        System.out.println("Se encontraron " + lista.size() + " capturas.");
//        
//        // Imprimimos la primera captura para validar que los datos (DTOs anidados)
//        // se están instanciando correctamente.
//        CapturaDTO primeraCaptura = lista.get(0);
//        assertNotNull(primeraCaptura.getCamara(), "La cámara de la primera captura es nula.");
//        assertNotNull(primeraCaptura.getPlaca(), "La placa de la primera captura es nula.");
//
//        System.out.println(
//            "Datos de la primera captura: " +
//            "ID: " + primeraCaptura.getId() +
//            ", Placa: " + primeraCaptura.getPlaca() +
//            ", Camara Model: " + primeraCaptura.getCamara().getModelo() +
//            ", Vehiculo Marca: " + (primeraCaptura.getVehiculo() != null ? primeraCaptura.getVehiculo().getMarca() : "N/A")
//        );
//    }
//    @Test
//    public void testListarTodosFederado() {
//        System.out.println("listarTodosFederado (usando SP en 2 BDs)");
//        
//        // 1. EJECUCIÓN
//        // Llama a CapturaDAOImp.leerTodos()
//        // que a su vez llama a DAOImplBase.listarTodosFederado()
//        List<CapturaDTO> listaCombinada = this.capturaDAO.leerTodos();
//        
//        // 2. VERIFICACIÓN (Assertions)
//        
//        // Verificamos que la lista no sea nula
//        // (Incluso si AMBAS BD fallan, debe retornar una lista vacía, no nula)
//        assertNotNull(listaCombinada, "La lista (federada) no debe ser nula.");
//        
//        // Verificamos que la lista contenga elementos
//        // (Esto asume que AL MENOS UNA de tus BDs tiene datos)
//        assertFalse(listaCombinada.isEmpty(), "La lista (federada) no debe estar vacía. " +
//                                               "Asegúrate de tener datos en al menos una BD.");
//        
//        // 3. VERIFICACIÓN VISUAL (Opcional)
//        System.out.println("Se encontraron " + listaCombinada.size() + " capturas en TOTAL (MySQL + MSSQL).");
//        
//        // Imprimimos la primera captura para validar el mapeo
//        CapturaDTO primeraCaptura = listaCombinada.get(0);
//        assertNotNull(primeraCaptura.getCamara(), "La cámara de la primera captura es nula.");
//        assertNotNull(primeraCaptura.getPlaca(), "La placa de la primera captura es nula.");
//
//        System.out.println(
//            "Datos de la primera captura (de la lista combinada): " +
//            "ID: " + primeraCaptura.getId() +
//            ", Placa: " + primeraCaptura.getPlaca() +
//            ", Camara Model: " + primeraCaptura.getCamara().getModelo()
//        );
//    }
    
}
