package pe.edu.pucp.transitsoft.clienteBO;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.ws.rs.core.Response;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import transitsoft.model.InfraccionDTO;

/**
 *
 * @author USUARIO
 */
public class InfraccionBOClient {
    private HttpClient cliente;
    private HttpRequest request;
    private HttpResponse<String> response;
    private String url;
    private ObjectMapper mapper;

    public InfraccionBOClient() {
        this.url = "http://localhost:8080/TransitSoftWS/resources/infracciones";
        this.mapper = new ObjectMapper();
        this.mapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss"));
    }

    public Integer insertar(InfraccionDTO infraccionDTO) 
            throws JsonProcessingException, IOException, InterruptedException {
        this.crearHttpClient();
        String jsonRequest = this.serializarDTO(infraccionDTO);
        this.crearHttpRequestPOST(jsonRequest);
        this.enviarRequest();
        InfraccionDTO infraccionRespuesta = this.deserializar(InfraccionDTO.class);
        this.cerrarHttpClient();
        
        if (response.statusCode() == Response.Status.CREATED.getStatusCode()) {
            return infraccionRespuesta.getId();
        }
        return 0;
    }

    public Integer modificar(InfraccionDTO infraccionDTO) 
            throws JsonProcessingException, IOException, InterruptedException {
        this.crearHttpClient();
        String jsonRequest = this.serializarDTO(infraccionDTO);
        this.crearHttpRequestPUT(jsonRequest);
        this.enviarRequest();
        this.cerrarHttpClient();
        
        if (this.response.statusCode() == Response.Status.OK.getStatusCode())
            return infraccionDTO.getId();
        return 0;
    }

    public Integer eliminar(Integer infraccionId) throws IOException, InterruptedException {
        this.crearHttpClient();
        this.crearHttpRequestDELETE(infraccionId);
        this.enviarRequest();
        this.cerrarHttpClient();
        
        if (this.response.statusCode() == Response.Status.NO_CONTENT.getStatusCode()) {
            return infraccionId;
        }
        return 0;
    }

    public InfraccionDTO obtenerPorId(Integer infraccionId) throws IOException, InterruptedException {
        this.crearHttpClient();
        this.crearHttpRequestGET(infraccionId);
        this.enviarRequest();
        this.cerrarHttpClient();
        
        if (this.response.statusCode() == Response.Status.NOT_FOUND.getStatusCode()) {
            return null;
        }
        InfraccionDTO infraccionDTORespuesta = this.deserializar(InfraccionDTO.class);
        return infraccionDTORespuesta;
    }

    public ArrayList<InfraccionDTO> listarTodos() throws IOException, InterruptedException {
        this.crearHttpClient();
        this.crearHttpRequestGET();
        this.enviarRequest();
        this.cerrarHttpClient();
        
        ArrayList<InfraccionDTO> listaInfracciones = this.deserializarListaDTO(
                new TypeReference<ArrayList<InfraccionDTO>>() {});
        return listaInfracciones;
    }

    public ArrayList<InfraccionDTO> buscarPorPlaca(String placa) throws IOException, InterruptedException {
        this.crearHttpClient();
        this.crearHttpRequestGETConQuery("buscar/placa", "placa", placa);
        this.enviarRequest();
        this.cerrarHttpClient();
        
        ArrayList<InfraccionDTO> listaInfracciones = this.deserializarListaDTO(
                new TypeReference<ArrayList<InfraccionDTO>>() {});
        return listaInfracciones;
    }

    public ArrayList<InfraccionDTO> buscarPorRangoFechas(Date fechaInicio, Date fechaFin) 
            throws IOException, InterruptedException {
        this.crearHttpClient();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String strFechaInicio = sdf.format(fechaInicio);
        String strFechaFin = sdf.format(fechaFin);
        String path = "buscar/fechas?fechaInicio=" + strFechaInicio + "&fechaFin=" + strFechaFin;
        this.crearHttpRequestGETConPath(path);
        this.enviarRequest();
        this.cerrarHttpClient();
        
        ArrayList<InfraccionDTO> listaInfracciones = this.deserializarListaDTO(
                new TypeReference<ArrayList<InfraccionDTO>>() {});
        return listaInfracciones;
    }

    public ArrayList<InfraccionDTO> buscarPorExcesoMayorA(Double excesoMinimo) 
            throws IOException, InterruptedException {
        this.crearHttpClient();
        this.crearHttpRequestGETConPath("buscar/exceso/" + excesoMinimo);
        this.enviarRequest();
        this.cerrarHttpClient();
        
        ArrayList<InfraccionDTO> listaInfracciones = this.deserializarListaDTO(
                new TypeReference<ArrayList<InfraccionDTO>>() {});
        return listaInfracciones;
    }

    public ArrayList<InfraccionDTO> buscarPorCamara(Integer camaraId) throws IOException, InterruptedException {
        this.crearHttpClient();
        this.crearHttpRequestGETConPath("buscar/camara/" + camaraId);
        this.enviarRequest();
        this.cerrarHttpClient();
        
        ArrayList<InfraccionDTO> listaInfracciones = this.deserializarListaDTO(
                new TypeReference<ArrayList<InfraccionDTO>>() {});
        return listaInfracciones;
    }

    public Double calcularMontoTotal() throws IOException, InterruptedException {
        this.crearHttpClient();
        this.crearHttpRequestGETConPath("monto-total");
        this.enviarRequest();
        this.cerrarHttpClient();
        
        // El servicio devuelve: {"montoTotal": 1234.56}
        String jsonResponse = this.response.body();
        ObjectMapper localMapper = new ObjectMapper();
        var jsonNode = localMapper.readTree(jsonResponse);
        return jsonNode.get("montoTotal").asDouble();
    }

    public Double calcularMontoTotalPorPlaca(String placa) throws IOException, InterruptedException {
        this.crearHttpClient();
        this.crearHttpRequestGETConQuery("monto-total/placa", "placa", placa);
        this.enviarRequest();
        this.cerrarHttpClient();
        
        // El servicio devuelve: {"placa": "ABC123", "montoTotal": 1234.56}
        String jsonResponse = this.response.body();
        ObjectMapper localMapper = new ObjectMapper();
        var jsonNode = localMapper.readTree(jsonResponse);
        return jsonNode.get("montoTotal").asDouble();
    }

    // Métodos privados auxiliares
    private void crearHttpClient() {
        this.cliente = HttpClient.newHttpClient();
    }

    private void cerrarHttpClient() {
        this.cliente.close();
    }

    private void crearHttpRequestPOST(String jsonRequest) {
        this.request = HttpRequest.newBuilder()
                .uri(URI.create(this.url))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(jsonRequest))
                .build();
    }

    private void crearHttpRequestPUT(String jsonRequest) {
        this.request = HttpRequest.newBuilder()
                .uri(URI.create(this.url))
                .header("Content-Type", "application/json")
                .PUT(HttpRequest.BodyPublishers.ofString(jsonRequest))
                .build();
    }

    private void crearHttpRequestDELETE(Integer infraccionId) {
        this.request = HttpRequest.newBuilder()
                .uri(URI.create(this.url + "/" + infraccionId))
                .header("Content-Type", "application/json")
                .DELETE()
                .build();
    }

    private void crearHttpRequestGET() {
        Integer infraccionId = null;
        this.crearHttpRequestGET(infraccionId);
    }

    private void crearHttpRequestGET(Integer infraccionId) {
        String URLGET = this.url;
        if (infraccionId != null) {
            URLGET = URLGET.concat("/" + infraccionId);
        }
        this.request = HttpRequest.newBuilder()
                .uri(URI.create(URLGET))
                .header("Content-Type", "application/json")
                .GET()
                .build();
    }

    private void crearHttpRequestGETConQuery(String path, String paramName, String paramValue) {
        String URLGET = this.url + "/" + path + "?" + paramName + "=" + paramValue;
        this.request = HttpRequest.newBuilder()
                .uri(URI.create(URLGET))
                .header("Content-Type", "application/json")
                .GET()
                .build();
    }

    private void crearHttpRequestGETConPath(String path) {
        String URLGET = this.url + "/" + path;
        this.request = HttpRequest.newBuilder()
                .uri(URI.create(URLGET))
                .header("Content-Type", "application/json")
                .GET()
                .build();
    }

    private void enviarRequest() throws IOException, InterruptedException {
        this.response = this.cliente.send(this.request, HttpResponse.BodyHandlers.ofString());
    }

    private String serializarDTO(InfraccionDTO infraccionDTO) throws JsonProcessingException {
        String jsonRequest = this.mapper.writeValueAsString(infraccionDTO);
        return jsonRequest;
    }

    private InfraccionDTO deserializar(Class<InfraccionDTO> clase) throws JsonProcessingException {
        InfraccionDTO infraccionRespuesta = mapper.readValue(response.body(), clase);
        return infraccionRespuesta;
    }

    private ArrayList<InfraccionDTO> deserializarListaDTO(TypeReference<ArrayList<InfraccionDTO>> typeReference) 
            throws JsonProcessingException {
        ArrayList<InfraccionDTO> listaInfracciones = this.mapper.readValue(this.response.body(), typeReference);
        return listaInfracciones;
    }
}