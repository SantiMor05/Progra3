package pe.edu.pucp.transitsoft.clienteBO;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.ws.rs.core.Response;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import transitsoft.model.CapturaDTO;

/**
 *
 * @author USUARIO
 */
public class CapturaBOClient {
    private HttpClient cliente;
    private HttpRequest request;
    private HttpResponse<String> response;
    private String url;
    private ObjectMapper mapper;

    public CapturaBOClient() {
        this.url = "http://localhost:8080/TransitSoftWS/resources/capturas";
        this.mapper = new ObjectMapper();
        this.mapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss"));
    }

    public Integer insertar(CapturaDTO capturaDTO) 
            throws JsonProcessingException, IOException, InterruptedException {
        this.crearHttpClient();
        String jsonRequest = this.serializarDTO(capturaDTO);
        this.crearHttpRequestPOST(jsonRequest);
        this.enviarRequest();
        CapturaDTO capturaRespuesta = this.deserializar(CapturaDTO.class);
        this.cerrarHttpClient();
        
        if (response.statusCode() == Response.Status.CREATED.getStatusCode()) {
            return capturaRespuesta.getId();
        }
        return 0;
    }

    public Integer modificar(CapturaDTO capturaDTO) 
            throws JsonProcessingException, IOException, InterruptedException {
        this.crearHttpClient();
        String jsonRequest = this.serializarDTO(capturaDTO);
        this.crearHttpRequestPUT(jsonRequest);
        this.enviarRequest();
        this.cerrarHttpClient();
        
        if (this.response.statusCode() == Response.Status.OK.getStatusCode())
            return capturaDTO.getId();
        return 0;
    }

    public Integer actualizar(CapturaDTO capturaDTO) 
            throws JsonProcessingException, IOException, InterruptedException {
        this.crearHttpClient();
        String jsonRequest = this.serializarDTO(capturaDTO);
        this.crearHttpRequestPUTConPath("actualizar", jsonRequest);
        this.enviarRequest();
        this.cerrarHttpClient();
        
        if (this.response.statusCode() == Response.Status.OK.getStatusCode())
            return capturaDTO.getId();
        return 0;
    }

    public Integer eliminar(Integer capturaId) throws IOException, InterruptedException {
        this.crearHttpClient();
        this.crearHttpRequestDELETE(capturaId);
        this.enviarRequest();
        this.cerrarHttpClient();
        
        if (this.response.statusCode() == Response.Status.NO_CONTENT.getStatusCode()) {
            return capturaId;
        }
        return 0;
    }

    public CapturaDTO obtenerPorId(Integer capturaId) throws IOException, InterruptedException {
        this.crearHttpClient();
        this.crearHttpRequestGET(capturaId);
        this.enviarRequest();
        this.cerrarHttpClient();
        
        if (this.response.statusCode() == Response.Status.NOT_FOUND.getStatusCode()) {
            return null;
        }
        CapturaDTO capturaDTORespuesta = this.deserializar(CapturaDTO.class);
        return capturaDTORespuesta;
    }

    public ArrayList<CapturaDTO> listarTodos() throws IOException, InterruptedException {
        this.crearHttpClient();
        this.crearHttpRequestGET();
        this.enviarRequest();
        this.cerrarHttpClient();
        
        ArrayList<CapturaDTO> listaCapturas = this.deserializarListaDTO(
                new TypeReference<ArrayList<CapturaDTO>>() {});
        return listaCapturas;
    }

    public List<CapturaDTO> leerTodos() throws IOException, InterruptedException {
        this.crearHttpClient();
        this.crearHttpRequestGETConPath("leer-todos");
        this.enviarRequest();
        this.cerrarHttpClient();
        
        List<CapturaDTO> listaCapturas = this.deserializarListaDTO(
                new TypeReference<List<CapturaDTO>>() {});
        return listaCapturas;
    }

    public List<CapturaDTO> obtenerCapturasConExcesoDeVelocidad() throws IOException, InterruptedException {
        this.crearHttpClient();
        this.crearHttpRequestGETConPath("exceso-velocidad");
        this.enviarRequest();
        this.cerrarHttpClient();
        
        List<CapturaDTO> listaCapturas = this.deserializarListaDTO(
                new TypeReference<List<CapturaDTO>>() {});
        return listaCapturas;
    }

    public List<CapturaDTO> obtenerCapturasConExcesoDeVelocidadConLimite(Double limite) 
            throws IOException, InterruptedException {
        this.crearHttpClient();
        this.crearHttpRequestGETConPath("exceso-velocidad/" + limite);
        this.enviarRequest();
        this.cerrarHttpClient();
        
        List<CapturaDTO> listaCapturas = this.deserializarListaDTO(
                new TypeReference<List<CapturaDTO>>() {});
        return listaCapturas;
    }

    public List<CapturaDTO> buscarPorPlaca(String placa) throws IOException, InterruptedException {
        this.crearHttpClient();
        this.crearHttpRequestGETConQuery("buscar/placa", "placa", placa);
        this.enviarRequest();
        this.cerrarHttpClient();
        
        List<CapturaDTO> listaCapturas = this.deserializarListaDTO(
                new TypeReference<List<CapturaDTO>>() {});
        return listaCapturas;
    }

    public List<CapturaDTO> buscarPorEstado(String estado) throws IOException, InterruptedException {
        this.crearHttpClient();
        this.crearHttpRequestGETConPath("buscar/estado/" + estado);
        this.enviarRequest();
        this.cerrarHttpClient();
        
        List<CapturaDTO> listaCapturas = this.deserializarListaDTO(
                new TypeReference<List<CapturaDTO>>() {});
        return listaCapturas;
    }

    public List<CapturaDTO> buscarPorRangoFechas(Date fechaInicio, Date fechaFin) 
            throws IOException, InterruptedException {
        this.crearHttpClient();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String strFechaInicio = sdf.format(fechaInicio);
        String strFechaFin = sdf.format(fechaFin);
        String path = "buscar/fechas?fechaInicio=" + strFechaInicio + "&fechaFin=" + strFechaFin;
        this.crearHttpRequestGETConPath(path);
        this.enviarRequest();
        this.cerrarHttpClient();
        
        List<CapturaDTO> listaCapturas = this.deserializarListaDTO(
                new TypeReference<List<CapturaDTO>>() {});
        return listaCapturas;
    }

    public List<CapturaDTO> buscarPorCamara(Integer camaraId) throws IOException, InterruptedException {
        this.crearHttpClient();
        this.crearHttpRequestGETConPath("buscar/camara/" + camaraId);
        this.enviarRequest();
        this.cerrarHttpClient();
        
        List<CapturaDTO> listaCapturas = this.deserializarListaDTO(
                new TypeReference<List<CapturaDTO>>() {});
        return listaCapturas;
    }

    public void marcarComoProcesado(Integer capturaId) throws IOException, InterruptedException {
        this.crearHttpClient();
        this.crearHttpRequestPUTVacio("marcar-procesado/" + capturaId);
        this.enviarRequest();
        this.cerrarHttpClient();
    }

    // Métodos privados auxiliares
    private void crearHttpClient() {
        this.cliente = HttpClient.newHttpClient();
    }

    private void cerrarHttpClient() {
        this.cliente.close();
    }

    private void crearHttpRequestPOST(String jsonRequest) {
        this.request = HttpRequest.newBuilder()
                .uri(URI.create(this.url))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(jsonRequest))
                .build();
    }

    private void crearHttpRequestPUT(String jsonRequest) {
        this.request = HttpRequest.newBuilder()
                .uri(URI.create(this.url))
                .header("Content-Type", "application/json")
                .PUT(HttpRequest.BodyPublishers.ofString(jsonRequest))
                .build();
    }

    private void crearHttpRequestPUTConPath(String path, String jsonRequest) {
        String URLPUT = this.url + "/" + path;
        this.request = HttpRequest.newBuilder()
                .uri(URI.create(URLPUT))
                .header("Content-Type", "application/json")
                .PUT(HttpRequest.BodyPublishers.ofString(jsonRequest))
                .build();
    }

    private void crearHttpRequestPUTVacio(String path) {
        String URLPUT = this.url + "/" + path;
        this.request = HttpRequest.newBuilder()
                .uri(URI.create(URLPUT))
                .header("Content-Type", "application/json")
                .PUT(HttpRequest.BodyPublishers.noBody())
                .build();
    }

    private void crearHttpRequestDELETE(Integer capturaId) {
        this.request = HttpRequest.newBuilder()
                .uri(URI.create(this.url + "/" + capturaId))
                .header("Content-Type", "application/json")
                .DELETE()
                .build();
    }

    private void crearHttpRequestGET() {
        Integer capturaId = null;
        this.crearHttpRequestGET(capturaId);
    }

    private void crearHttpRequestGET(Integer capturaId) {
        String URLGET = this.url;
        if (capturaId != null) {
            URLGET = URLGET.concat("/" + capturaId);
        }
        this.request = HttpRequest.newBuilder()
                .uri(URI.create(URLGET))
                .header("Content-Type", "application/json")
                .GET()
                .build();
    }

    private void crearHttpRequestGETConQuery(String path, String paramName, String paramValue) {
        String URLGET = this.url + "/" + path + "?" + paramName + "=" + paramValue;
        this.request = HttpRequest.newBuilder()
                .uri(URI.create(URLGET))
                .header("Content-Type", "application/json")
                .GET()
                .build();
    }

    private void crearHttpRequestGETConPath(String path) {
        String URLGET = this.url + "/" + path;
        this.request = HttpRequest.newBuilder()
                .uri(URI.create(URLGET))
                .header("Content-Type", "application/json")
                .GET()
                .build();
    }

    private void enviarRequest() throws IOException, InterruptedException {
        this.response = this.cliente.send(this.request, HttpResponse.BodyHandlers.ofString());
    }

    private String serializarDTO(CapturaDTO capturaDTO) throws JsonProcessingException {
        String jsonRequest = this.mapper.writeValueAsString(capturaDTO);
        return jsonRequest;
    }

    private CapturaDTO deserializar(Class<CapturaDTO> clase) throws JsonProcessingException {
        CapturaDTO capturaRespuesta = mapper.readValue(response.body(), clase);
        return capturaRespuesta;
    }

    private <T> T deserializarListaDTO(TypeReference<T> typeReference) 
            throws JsonProcessingException {
        T listaCapturas = this.mapper.readValue(this.response.body(), typeReference);
        return listaCapturas;
    }
}