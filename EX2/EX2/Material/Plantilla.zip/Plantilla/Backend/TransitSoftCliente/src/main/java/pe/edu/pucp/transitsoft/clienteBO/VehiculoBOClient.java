package pe.edu.pucp.transitsoft.clienteBO;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.ws.rs.core.Response;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import transitsoft.model.VehiculoDTO;

/**
 *
 * @author USUARIO
 */
public class VehiculoBOClient {

    private HttpClient cliente;
    private HttpRequest request;
    private HttpResponse<String> response;
    private String url;
    private ObjectMapper mapper;

    public VehiculoBOClient() {
        this.url = "http://localhost:8080/TransitSoftWS/resources/vehiculos";
        this.mapper = new ObjectMapper();
    }

    public Integer insertar(String placa, String marca, String modelo, Integer anho) 
            throws JsonProcessingException, IOException, InterruptedException {
        this.crearHttpClient();
        VehiculoDTO vehiculoDTO = this.crearDTO(placa, marca, modelo, anho);
        String jsonRequest = this.serializarDTO(vehiculoDTO);
        this.crearHttpRequestPOST(jsonRequest);
        this.enviarRequest();
        VehiculoDTO vehiculoRespuesta = this.deserializar(VehiculoDTO.class);
        this.cerrarHttpClient();

        if (response.statusCode() == Response.Status.CREATED.getStatusCode()) {
            return vehiculoRespuesta.getId();
        }
        return 0;
    }

    public Integer modificar(Integer id, String placa, String marca, String modelo, Integer anho) 
            throws JsonProcessingException, IOException, InterruptedException {
        this.crearHttpClient();
        VehiculoDTO vehiculoDTO = this.crearDTO(id, placa, marca, modelo, anho);
        String jsonRequest = this.serializarDTO(vehiculoDTO);
        this.crearHttpRequestPUT(jsonRequest);
        this.enviarRequest();
        this.cerrarHttpClient();
        
        if (this.response.statusCode() == Response.Status.OK.getStatusCode())
            return id;
        return 0;
    }

    public Integer eliminar(Integer vehiculoId) throws IOException, InterruptedException {
        this.crearHttpClient();
        this.crearHttpRequestDELETE(vehiculoId);
        this.enviarRequest();
        this.cerrarHttpClient();

        if (this.response.statusCode() == Response.Status.NO_CONTENT.getStatusCode()) {
            return vehiculoId;
        }
        return 0;
    }

    public VehiculoDTO obtenerPorId(Integer vehiculoId) throws IOException, InterruptedException {
        this.crearHttpClient();
        this.crearHttpRequestGET(vehiculoId);
        this.enviarRequest();
        this.cerrarHttpClient();
        
        if (this.response.statusCode() == Response.Status.NOT_FOUND.getStatusCode()) {
            return null;
        }
        VehiculoDTO vehiculoDTORespuesta = this.deserializar(VehiculoDTO.class);
        return vehiculoDTORespuesta;
    }

    public ArrayList<VehiculoDTO> listarTodos() throws IOException, InterruptedException {
        this.crearHttpClient();
        this.crearHttpRequestGET();
        this.enviarRequest();
        this.cerrarHttpClient();
        
        ArrayList<VehiculoDTO> listaVehiculos = this.deserializarListaDTO(
                new TypeReference<ArrayList<VehiculoDTO>>() {});
        return listaVehiculos;
    }

    public ArrayList<VehiculoDTO> buscarPorPlaca(String placa) throws IOException, InterruptedException {
        this.crearHttpClient();
        this.crearHttpRequestGETConQuery("buscar/placa", "placa", placa);
        this.enviarRequest();
        this.cerrarHttpClient();
        
        ArrayList<VehiculoDTO> listaVehiculos = this.deserializarListaDTO(
                new TypeReference<ArrayList<VehiculoDTO>>() {});
        return listaVehiculos;
    }

    public ArrayList<VehiculoDTO> buscarPorMarca(String marca) throws IOException, InterruptedException {
        this.crearHttpClient();
        this.crearHttpRequestGETConQuery("buscar/marca", "marca", marca);
        this.enviarRequest();
        this.cerrarHttpClient();
        
        ArrayList<VehiculoDTO> listaVehiculos = this.deserializarListaDTO(
                new TypeReference<ArrayList<VehiculoDTO>>() {});
        return listaVehiculos;
    }

    public ArrayList<VehiculoDTO> buscarPorAnio(Integer anio) throws IOException, InterruptedException {
        this.crearHttpClient();
        this.crearHttpRequestGETConPath("buscar/anio/" + anio);
        this.enviarRequest();
        this.cerrarHttpClient();
        
        ArrayList<VehiculoDTO> listaVehiculos = this.deserializarListaDTO(
                new TypeReference<ArrayList<VehiculoDTO>>() {});
        return listaVehiculos;
    }

    // Métodos privados auxiliares
    private void crearHttpClient() {
        this.cliente = HttpClient.newHttpClient();
    }

    private void cerrarHttpClient() {
        this.cliente.close();
    }

    private void crearHttpRequestPOST(String jsonRequest) {
        this.request = HttpRequest.newBuilder()
                .uri(URI.create(this.url))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(jsonRequest))
                .build();
    }

    private void crearHttpRequestPUT(String jsonRequest) {
        this.request = HttpRequest.newBuilder()
                .uri(URI.create(this.url))
                .header("Content-Type", "application/json")
                .PUT(HttpRequest.BodyPublishers.ofString(jsonRequest))
                .build();
    }

    private void crearHttpRequestDELETE(Integer vehiculoId) {
        this.request = HttpRequest.newBuilder()
                .uri(URI.create(this.url + "/" + vehiculoId))
                .header("Content-Type", "application/json")
                .DELETE()
                .build();
    }

    private void crearHttpRequestGET() {
        Integer vehiculoId = null;
        this.crearHttpRequestGET(vehiculoId);
    }

    private void crearHttpRequestGET(Integer vehiculoId) {
        String URLGET = this.url;
        if (vehiculoId != null) {
            URLGET = URLGET.concat("/" + vehiculoId);
        }
        this.request = HttpRequest.newBuilder()
                .uri(URI.create(URLGET))
                .header("Content-Type", "application/json")
                .GET()
                .build();
    }

    private void crearHttpRequestGETConQuery(String path, String paramName, String paramValue) {
        String URLGET = this.url + "/" + path + "?" + paramName + "=" + paramValue;
        this.request = HttpRequest.newBuilder()
                .uri(URI.create(URLGET))
                .header("Content-Type", "application/json")
                .GET()
                .build();
    }

    private void crearHttpRequestGETConPath(String path) {
        String URLGET = this.url + "/" + path;
        this.request = HttpRequest.newBuilder()
                .uri(URI.create(URLGET))
                .header("Content-Type", "application/json")
                .GET()
                .build();
    }

    private void enviarRequest() throws IOException, InterruptedException {
        this.response = this.cliente.send(this.request, HttpResponse.BodyHandlers.ofString());
    }

    private VehiculoDTO crearDTO(String placa, String marca, String modelo, Integer anho) {
        Integer id = null;
        return this.crearDTO(id, placa, marca, modelo, anho);
    }

    private VehiculoDTO crearDTO(Integer id, String placa, String marca, String modelo, Integer anho) {
        VehiculoDTO vehiculoDTO = new VehiculoDTO();
        vehiculoDTO.setId(id);
        vehiculoDTO.setPlaca(placa);
        vehiculoDTO.setMarca(marca);
        vehiculoDTO.setModelo(modelo);
        vehiculoDTO.setAnho(anho);
        return vehiculoDTO;
    }

    private String serializarDTO(VehiculoDTO vehiculoDTO) throws JsonProcessingException {
        String jsonRequest = this.mapper.writeValueAsString(vehiculoDTO);
        return jsonRequest;
    }

    private VehiculoDTO deserializar(Class<VehiculoDTO> clase) throws JsonProcessingException {
        VehiculoDTO vehiculoRespuesta = mapper.readValue(response.body(), clase);
        return vehiculoRespuesta;
    }

    private ArrayList<VehiculoDTO> deserializarListaDTO(TypeReference<ArrayList<VehiculoDTO>> typeReference) 
            throws JsonProcessingException {
        ArrayList<VehiculoDTO> listaVehiculos = this.mapper.readValue(this.response.body(), typeReference);
        return listaVehiculos;
    }
}