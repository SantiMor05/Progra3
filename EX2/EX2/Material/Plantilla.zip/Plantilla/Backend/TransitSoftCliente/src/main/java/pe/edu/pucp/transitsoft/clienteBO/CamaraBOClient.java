package pe.edu.pucp.transitsoft.clienteBO;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.ws.rs.core.Response;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import transitsoft.model.CamaraDTO;

/**
 *
 * @author USUARIO
 */
public class CamaraBOClient {
    private HttpClient cliente;
    private HttpRequest request;
    private HttpResponse<String> response;
    private String url;
    private ObjectMapper mapper;

    public CamaraBOClient() {
        this.url = "http://localhost:8080/TransitSoftWS/resources/camaras";
        this.mapper = new ObjectMapper();
    }

    public Integer insertar(String modelo, String codigoSerie, Integer latitud, Integer longitud) 
            throws JsonProcessingException, IOException, InterruptedException {
        this.crearHttpClient();
        CamaraDTO camaraDTO = this.crearDTO(modelo, codigoSerie, latitud, longitud);
        String jsonRequest = this.serializarDTO(camaraDTO);
        this.crearHttpRequestPOST(jsonRequest);
        this.enviarRequest();
        CamaraDTO camaraRespuesta = this.deserializar(CamaraDTO.class);
        this.cerrarHttpClient();
        
        if (response.statusCode() == Response.Status.CREATED.getStatusCode()) {
            return camaraRespuesta.getId();
        }
        return 0;
    }

    public Integer modificar(Integer id, String modelo, String codigoSerie, Integer latitud, Integer longitud) 
            throws JsonProcessingException, IOException, InterruptedException {
        this.crearHttpClient();
        CamaraDTO camaraDTO = this.crearDTO(id, modelo, codigoSerie, latitud, longitud);
        String jsonRequest = this.serializarDTO(camaraDTO);
        this.crearHttpRequestPUT(jsonRequest);
        this.enviarRequest();
        this.cerrarHttpClient();
        
        if (this.response.statusCode() == Response.Status.OK.getStatusCode())
            return id;
        return 0;
    }

    public Integer eliminar(Integer camaraId) throws IOException, InterruptedException {
        this.crearHttpClient();
        this.crearHttpRequestDELETE(camaraId);
        this.enviarRequest();
        this.cerrarHttpClient();
        
        if (this.response.statusCode() == Response.Status.NO_CONTENT.getStatusCode()) {
            return camaraId;
        }
        return 0;
    }

    public CamaraDTO obtenerPorId(Integer camaraId) throws IOException, InterruptedException {
        this.crearHttpClient();
        this.crearHttpRequestGET(camaraId);
        this.enviarRequest();
        this.cerrarHttpClient();
        
        if (this.response.statusCode() == Response.Status.NOT_FOUND.getStatusCode()) {
            return null;
        }
        CamaraDTO camaraDTORespuesta = this.deserializar(CamaraDTO.class);
        return camaraDTORespuesta;
    }

    public ArrayList<CamaraDTO> listarTodos() throws IOException, InterruptedException {
        this.crearHttpClient();
        this.crearHttpRequestGET();
        this.enviarRequest();
        this.cerrarHttpClient();
        
        ArrayList<CamaraDTO> listaCamaras = this.deserializarListaDTO(
                new TypeReference<ArrayList<CamaraDTO>>() {});
        return listaCamaras;
    }

    public ArrayList<CamaraDTO> buscarPorModelo(String modelo) throws IOException, InterruptedException {
        this.crearHttpClient();
        this.crearHttpRequestGETConQuery("buscar/modelo", "modelo", modelo);
        this.enviarRequest();
        this.cerrarHttpClient();
        
        ArrayList<CamaraDTO> listaCamaras = this.deserializarListaDTO(
                new TypeReference<ArrayList<CamaraDTO>>() {});
        return listaCamaras;
    }

    public ArrayList<CamaraDTO> buscarPorCodigoSerie(String codigoSerie) throws IOException, InterruptedException {
        this.crearHttpClient();
        this.crearHttpRequestGETConQuery("buscar/codigo-serie", "codigoSerie", codigoSerie);
        this.enviarRequest();
        this.cerrarHttpClient();
        
        ArrayList<CamaraDTO> listaCamaras = this.deserializarListaDTO(
                new TypeReference<ArrayList<CamaraDTO>>() {});
        return listaCamaras;
    }

    public ArrayList<CamaraDTO> buscarPorZonaGeografica(Integer latMin, Integer latMax, Integer longMin, Integer longMax) 
            throws IOException, InterruptedException {
        this.crearHttpClient();
        String path = "buscar/zona?latMin=" + latMin + "&latMax=" + latMax + 
                     "&longMin=" + longMin + "&longMax=" + longMax;
        this.crearHttpRequestGETConPath(path);
        this.enviarRequest();
        this.cerrarHttpClient();
        
        ArrayList<CamaraDTO> listaCamaras = this.deserializarListaDTO(
                new TypeReference<ArrayList<CamaraDTO>>() {});
        return listaCamaras;
    }

    // Métodos privados auxiliares
    private void crearHttpClient() {
        this.cliente = HttpClient.newHttpClient();
    }

    private void cerrarHttpClient() {
        this.cliente.close();
    }

    private void crearHttpRequestPOST(String jsonRequest) {
        this.request = HttpRequest.newBuilder()
                .uri(URI.create(this.url))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(jsonRequest))
                .build();
    }

    private void crearHttpRequestPUT(String jsonRequest) {
        this.request = HttpRequest.newBuilder()
                .uri(URI.create(this.url))
                .header("Content-Type", "application/json")
                .PUT(HttpRequest.BodyPublishers.ofString(jsonRequest))
                .build();
    }

    private void crearHttpRequestDELETE(Integer camaraId) {
        this.request = HttpRequest.newBuilder()
                .uri(URI.create(this.url + "/" + camaraId))
                .header("Content-Type", "application/json")
                .DELETE()
                .build();
    }

    private void crearHttpRequestGET() {
        Integer camaraId = null;
        this.crearHttpRequestGET(camaraId);
    }

    private void crearHttpRequestGET(Integer camaraId) {
        String URLGET = this.url;
        if (camaraId != null) {
            URLGET = URLGET.concat("/" + camaraId);
        }
        this.request = HttpRequest.newBuilder()
                .uri(URI.create(URLGET))
                .header("Content-Type", "application/json")
                .GET()
                .build();
    }

    private void crearHttpRequestGETConQuery(String path, String paramName, String paramValue) {
        String URLGET = this.url + "/" + path + "?" + paramName + "=" + paramValue;
        this.request = HttpRequest.newBuilder()
                .uri(URI.create(URLGET))
                .header("Content-Type", "application/json")
                .GET()
                .build();
    }

    private void crearHttpRequestGETConPath(String path) {
        String URLGET = this.url + "/" + path;
        this.request = HttpRequest.newBuilder()
                .uri(URI.create(URLGET))
                .header("Content-Type", "application/json")
                .GET()
                .build();
    }

    private void enviarRequest() throws IOException, InterruptedException {
        this.response = this.cliente.send(this.request, HttpResponse.BodyHandlers.ofString());
    }

    private CamaraDTO crearDTO(String modelo, String codigoSerie, Integer latitud, Integer longitud) {
        Integer id = null;
        return this.crearDTO(id, modelo, codigoSerie, latitud, longitud);
    }

    private CamaraDTO crearDTO(Integer id, String modelo, String codigoSerie, Integer latitud, Integer longitud) {
        CamaraDTO camaraDTO = new CamaraDTO();
        camaraDTO.setId(id);
        camaraDTO.setModelo(modelo);
        camaraDTO.setCodigoSerie(codigoSerie);
        camaraDTO.setLatitud(latitud);
        camaraDTO.setLongitud(longitud);
        return camaraDTO;
    }

    private String serializarDTO(CamaraDTO camaraDTO) throws JsonProcessingException {
        String jsonRequest = this.mapper.writeValueAsString(camaraDTO);
        return jsonRequest;
    }

    private CamaraDTO deserializar(Class<CamaraDTO> clase) throws JsonProcessingException {
        CamaraDTO camaraRespuesta = mapper.readValue(response.body(), clase);
        return camaraRespuesta;
    }

    private ArrayList<CamaraDTO> deserializarListaDTO(TypeReference<ArrayList<CamaraDTO>> typeReference) 
            throws JsonProcessingException {
        ArrayList<CamaraDTO> listaCamaras = this.mapper.readValue(this.response.body(), typeReference);
        return listaCamaras;
    }
}