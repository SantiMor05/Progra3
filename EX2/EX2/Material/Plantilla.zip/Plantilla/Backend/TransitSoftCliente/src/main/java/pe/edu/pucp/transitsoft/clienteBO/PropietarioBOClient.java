package pe.edu.pucp.transitsoft.clienteBO;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.ws.rs.core.Response;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import transitsoft.model.PropietarioDTO;

/**
 *
 * @author USUARIO
 */
public class PropietarioBOClient {
    private HttpClient cliente;
    private HttpRequest request;
    private HttpResponse<String> response;
    private String url;
    private ObjectMapper mapper;

    public PropietarioBOClient() {
        this.url = "http://localhost:8080/TransitSoftWS/resources/propietarios";
        this.mapper = new ObjectMapper();
    }

    public Integer insertar(String dni, String nombres, String apellidos, String direccion) 
            throws JsonProcessingException, IOException, InterruptedException {
        this.crearHttpClient();
        PropietarioDTO propietarioDTO = this.crearDTO(dni, nombres, apellidos, direccion);
        String jsonRequest = this.serializarDTO(propietarioDTO);
        this.crearHttpRequestPOST(jsonRequest);
        this.enviarRequest();
        PropietarioDTO propietarioRespuesta = this.deserializar(PropietarioDTO.class);
        this.cerrarHttpClient();
        
        if (response.statusCode() == Response.Status.CREATED.getStatusCode()) {
            return propietarioRespuesta.getId();
        }
        return 0;
    }

    public Integer modificar(Integer id, String dni, String nombres, String apellidos, String direccion) 
            throws JsonProcessingException, IOException, InterruptedException {
        this.crearHttpClient();
        PropietarioDTO propietarioDTO = this.crearDTO(id, dni, nombres, apellidos, direccion);
        String jsonRequest = this.serializarDTO(propietarioDTO);
        this.crearHttpRequestPUT(jsonRequest);
        this.enviarRequest();
        this.cerrarHttpClient();
        
        if (this.response.statusCode() == Response.Status.OK.getStatusCode())
            return id;
        return 0;
    }

    public Integer eliminar(Integer propietarioId) throws IOException, InterruptedException {
        this.crearHttpClient();
        this.crearHttpRequestDELETE(propietarioId);
        this.enviarRequest();
        this.cerrarHttpClient();
        
        if (this.response.statusCode() == Response.Status.NO_CONTENT.getStatusCode()) {
            return propietarioId;
        }
        return 0;
    }

    public PropietarioDTO obtenerPorId(Integer propietarioId) throws IOException, InterruptedException {
        this.crearHttpClient();
        this.crearHttpRequestGET(propietarioId);
        this.enviarRequest();
        this.cerrarHttpClient();
        
        if (this.response.statusCode() == Response.Status.NOT_FOUND.getStatusCode()) {
            return null;
        }
        PropietarioDTO propietarioDTORespuesta = this.deserializar(PropietarioDTO.class);
        return propietarioDTORespuesta;
    }

    public ArrayList<PropietarioDTO> listarTodos() throws IOException, InterruptedException {
        this.crearHttpClient();
        this.crearHttpRequestGET();
        this.enviarRequest();
        this.cerrarHttpClient();
        
        ArrayList<PropietarioDTO> listaPropietarios = this.deserializarListaDTO(
                new TypeReference<ArrayList<PropietarioDTO>>() {});
        return listaPropietarios;
    }

    public ArrayList<PropietarioDTO> buscarPorDni(String dni) throws IOException, InterruptedException {
        this.crearHttpClient();
        this.crearHttpRequestGETConQuery("buscar/dni", "dni", dni);
        this.enviarRequest();
        this.cerrarHttpClient();
        
        ArrayList<PropietarioDTO> listaPropietarios = this.deserializarListaDTO(
                new TypeReference<ArrayList<PropietarioDTO>>() {});
        return listaPropietarios;
    }

    public ArrayList<PropietarioDTO> buscarPorNombre(String nombre) throws IOException, InterruptedException {
        this.crearHttpClient();
        this.crearHttpRequestGETConQuery("buscar/nombre", "nombre", nombre);
        this.enviarRequest();
        this.cerrarHttpClient();
        
        ArrayList<PropietarioDTO> listaPropietarios = this.deserializarListaDTO(
                new TypeReference<ArrayList<PropietarioDTO>>() {});
        return listaPropietarios;
    }

    // Métodos privados auxiliares
    private void crearHttpClient() {
        this.cliente = HttpClient.newHttpClient();
    }

    private void cerrarHttpClient() {
        this.cliente.close();
    }

    private void crearHttpRequestPOST(String jsonRequest) {
        this.request = HttpRequest.newBuilder()
                .uri(URI.create(this.url))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(jsonRequest))
                .build();
    }

    private void crearHttpRequestPUT(String jsonRequest) {
        this.request = HttpRequest.newBuilder()
                .uri(URI.create(this.url))
                .header("Content-Type", "application/json")
                .PUT(HttpRequest.BodyPublishers.ofString(jsonRequest))
                .build();
    }

    private void crearHttpRequestDELETE(Integer propietarioId) {
        this.request = HttpRequest.newBuilder()
                .uri(URI.create(this.url + "/" + propietarioId))
                .header("Content-Type", "application/json")
                .DELETE()
                .build();
    }

    private void crearHttpRequestGET() {
        Integer propietarioId = null;
        this.crearHttpRequestGET(propietarioId);
    }

    private void crearHttpRequestGET(Integer propietarioId) {
        String URLGET = this.url;
        if (propietarioId != null) {
            URLGET = URLGET.concat("/" + propietarioId);
        }
        this.request = HttpRequest.newBuilder()
                .uri(URI.create(URLGET))
                .header("Content-Type", "application/json")
                .GET()
                .build();
    }

    private void crearHttpRequestGETConQuery(String path, String paramName, String paramValue) {
        String URLGET = this.url + "/" + path + "?" + paramName + "=" + paramValue;
        this.request = HttpRequest.newBuilder()
                .uri(URI.create(URLGET))
                .header("Content-Type", "application/json")
                .GET()
                .build();
    }

    private void enviarRequest() throws IOException, InterruptedException {
        this.response = this.cliente.send(this.request, HttpResponse.BodyHandlers.ofString());
    }

    private PropietarioDTO crearDTO(String dni, String nombres, String apellidos, String direccion) {
        Integer id = null;
        return this.crearDTO(id, dni, nombres, apellidos, direccion);
    }

    private PropietarioDTO crearDTO(Integer id, String dni, String nombres, String apellidos, String direccion) {
        PropietarioDTO propietarioDTO = new PropietarioDTO();
        propietarioDTO.setId(id);
        propietarioDTO.setDni(dni);
        propietarioDTO.setNombres(nombres);
        propietarioDTO.setApellidos(apellidos);
        propietarioDTO.setDireccion(direccion);
        return propietarioDTO;
    }

    private String serializarDTO(PropietarioDTO propietarioDTO) throws JsonProcessingException {
        String jsonRequest = this.mapper.writeValueAsString(propietarioDTO);
        return jsonRequest;
    }

    private PropietarioDTO deserializar(Class<PropietarioDTO> clase) throws JsonProcessingException {
        PropietarioDTO propietarioRespuesta = mapper.readValue(response.body(), clase);
        return propietarioRespuesta;
    }

    private ArrayList<PropietarioDTO> deserializarListaDTO(TypeReference<ArrayList<PropietarioDTO>> typeReference) 
            throws JsonProcessingException {
        ArrayList<PropietarioDTO> listaPropietarios = this.mapper.readValue(this.response.body(), typeReference);
        return listaPropietarios;
    }
}