package pe.edu.pucp.transitsoft.clienteBO;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.ws.rs.core.Response;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import transitsoft.model.VehiculoPropietarioDTO;

/**
 *
 * @author USUARIO
 */
public class VehiculoPropietarioBOClient {
    private HttpClient cliente;
    private HttpRequest request;
    private HttpResponse<String> response;
    private String url;
    private ObjectMapper mapper;

    public VehiculoPropietarioBOClient() {
        this.url = "http://localhost:8080/TransitSoftWS/resources/vehiculo-propietarios";
        this.mapper = new ObjectMapper();
    }

    public Integer insertar(VehiculoPropietarioDTO vehiculoPropietarioDTO) 
            throws JsonProcessingException, IOException, InterruptedException {
        this.crearHttpClient();
        String jsonRequest = this.serializarDTO(vehiculoPropietarioDTO);
        this.crearHttpRequestPOST(jsonRequest);
        this.enviarRequest();
        VehiculoPropietarioDTO vpRespuesta = this.deserializar(VehiculoPropietarioDTO.class);
        this.cerrarHttpClient();
        
        if (response.statusCode() == Response.Status.CREATED.getStatusCode()) {
            return vpRespuesta.getId();
        }
        return 0;
    }

    public Integer modificar(VehiculoPropietarioDTO vehiculoPropietarioDTO) 
            throws JsonProcessingException, IOException, InterruptedException {
        this.crearHttpClient();
        String jsonRequest = this.serializarDTO(vehiculoPropietarioDTO);
        this.crearHttpRequestPUT(jsonRequest);
        this.enviarRequest();
        this.cerrarHttpClient();
        
        if (this.response.statusCode() == Response.Status.OK.getStatusCode())
            return vehiculoPropietarioDTO.getId();
        return 0;
    }

    public Integer eliminar(Integer vehiculoPropietarioId) throws IOException, InterruptedException {
        this.crearHttpClient();
        this.crearHttpRequestDELETE(vehiculoPropietarioId);
        this.enviarRequest();
        this.cerrarHttpClient();
        
        if (this.response.statusCode() == Response.Status.NO_CONTENT.getStatusCode()) {
            return vehiculoPropietarioId;
        }
        return 0;
    }

    public VehiculoPropietarioDTO obtenerPorId(Integer vehiculoPropietarioId) 
            throws IOException, InterruptedException {
        this.crearHttpClient();
        this.crearHttpRequestGET(vehiculoPropietarioId);
        this.enviarRequest();
        this.cerrarHttpClient();
        
        if (this.response.statusCode() == Response.Status.NOT_FOUND.getStatusCode()) {
            return null;
        }
        VehiculoPropietarioDTO vpDTORespuesta = this.deserializar(VehiculoPropietarioDTO.class);
        return vpDTORespuesta;
    }

    public ArrayList<VehiculoPropietarioDTO> listarTodos() throws IOException, InterruptedException {
        this.crearHttpClient();
        this.crearHttpRequestGET();
        this.enviarRequest();
        this.cerrarHttpClient();
        
        ArrayList<VehiculoPropietarioDTO> listaVP = this.deserializarListaDTO(
                new TypeReference<ArrayList<VehiculoPropietarioDTO>>() {});
        return listaVP;
    }

    public ArrayList<VehiculoPropietarioDTO> buscarPorVehiculoId(Integer vehiculoId) 
            throws IOException, InterruptedException {
        this.crearHttpClient();
        this.crearHttpRequestGETConPath("buscar/vehiculo/" + vehiculoId);
        this.enviarRequest();
        this.cerrarHttpClient();
        
        ArrayList<VehiculoPropietarioDTO> listaVP = this.deserializarListaDTO(
                new TypeReference<ArrayList<VehiculoPropietarioDTO>>() {});
        return listaVP;
    }

    public ArrayList<VehiculoPropietarioDTO> buscarPorPropietarioId(Integer propietarioId) 
            throws IOException, InterruptedException {
        this.crearHttpClient();
        this.crearHttpRequestGETConPath("buscar/propietario/" + propietarioId);
        this.enviarRequest();
        this.cerrarHttpClient();
        
        ArrayList<VehiculoPropietarioDTO> listaVP = this.deserializarListaDTO(
                new TypeReference<ArrayList<VehiculoPropietarioDTO>>() {});
        return listaVP;
    }

    public ArrayList<VehiculoPropietarioDTO> buscarPorPlaca(String placa) 
            throws IOException, InterruptedException {
        this.crearHttpClient();
        this.crearHttpRequestGETConQuery("buscar/placa", "placa", placa);
        this.enviarRequest();
        this.cerrarHttpClient();
        
        ArrayList<VehiculoPropietarioDTO> listaVP = this.deserializarListaDTO(
                new TypeReference<ArrayList<VehiculoPropietarioDTO>>() {});
        return listaVP;
    }

    // Métodos privados auxiliares
    private void crearHttpClient() {
        this.cliente = HttpClient.newHttpClient();
    }

    private void cerrarHttpClient() {
        this.cliente.close();
    }

    private void crearHttpRequestPOST(String jsonRequest) {
        this.request = HttpRequest.newBuilder()
                .uri(URI.create(this.url))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(jsonRequest))
                .build();
    }

    private void crearHttpRequestPUT(String jsonRequest) {
        this.request = HttpRequest.newBuilder()
                .uri(URI.create(this.url))
                .header("Content-Type", "application/json")
                .PUT(HttpRequest.BodyPublishers.ofString(jsonRequest))
                .build();
    }

    private void crearHttpRequestDELETE(Integer vehiculoPropietarioId) {
        this.request = HttpRequest.newBuilder()
                .uri(URI.create(this.url + "/" + vehiculoPropietarioId))
                .header("Content-Type", "application/json")
                .DELETE()
                .build();
    }

    private void crearHttpRequestGET() {
        Integer vehiculoPropietarioId = null;
        this.crearHttpRequestGET(vehiculoPropietarioId);
    }

    private void crearHttpRequestGET(Integer vehiculoPropietarioId) {
        String URLGET = this.url;
        if (vehiculoPropietarioId != null) {
            URLGET = URLGET.concat("/" + vehiculoPropietarioId);
        }
        this.request = HttpRequest.newBuilder()
                .uri(URI.create(URLGET))
                .header("Content-Type", "application/json")
                .GET()
                .build();
    }

    private void crearHttpRequestGETConQuery(String path, String paramName, String paramValue) {
        String URLGET = this.url + "/" + path + "?" + paramName + "=" + paramValue;
        this.request = HttpRequest.newBuilder()
                .uri(URI.create(URLGET))
                .header("Content-Type", "application/json")
                .GET()
                .build();
    }

    private void crearHttpRequestGETConPath(String path) {
        String URLGET = this.url + "/" + path;
        this.request = HttpRequest.newBuilder()
                .uri(URI.create(URLGET))
                .header("Content-Type", "application/json")
                .GET()
                .build();
    }

    private void enviarRequest() throws IOException, InterruptedException {
        this.response = this.cliente.send(this.request, HttpResponse.BodyHandlers.ofString());
    }

    private String serializarDTO(VehiculoPropietarioDTO vehiculoPropietarioDTO) throws JsonProcessingException {
        String jsonRequest = this.mapper.writeValueAsString(vehiculoPropietarioDTO);
        return jsonRequest;
    }

    private VehiculoPropietarioDTO deserializar(Class<VehiculoPropietarioDTO> clase) throws JsonProcessingException {
        VehiculoPropietarioDTO vpRespuesta = mapper.readValue(response.body(), clase);
        return vpRespuesta;
    }

    private ArrayList<VehiculoPropietarioDTO> deserializarListaDTO(
            TypeReference<ArrayList<VehiculoPropietarioDTO>> typeReference) 
            throws JsonProcessingException {
        ArrayList<VehiculoPropietarioDTO> listaVP = this.mapper.readValue(this.response.body(), typeReference);
        return listaVP;
    }
}