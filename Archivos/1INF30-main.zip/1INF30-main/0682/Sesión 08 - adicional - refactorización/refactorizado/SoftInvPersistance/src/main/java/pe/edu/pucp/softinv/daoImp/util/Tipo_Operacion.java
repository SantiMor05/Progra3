package pe.edu.pucp.softinv.daoImp.util;

public enum Tipo_Operacion {
    INSERTAR, MODIFICAR, ELIMINAR
}
