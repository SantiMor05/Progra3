package pe.edu.pucp.softinv.model;

public enum TipoOperacion {
    ENTRADA, SALIDA
}
