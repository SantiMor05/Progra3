package pe.edu.pucp.softinv.db.util;

public enum MotorDeBaseDeDatos {
    MYSQL, MSSQL
}
