package com.mycompany.holamundo_nb;

public class HolaMundo_NB {

    public static void main(String[] args) {
        System.out.println("Hola Mundo");
    }
}
